package co.edu.redsegura;

import co.edu.redsegura.core.DataFactory;
import co.edu.redsegura.core.RedSeguraCore;
import co.edu.redsegura.graph.BfsResult;
import co.edu.redsegura.graph.BreadthFirstSearch;
import co.edu.redsegura.graph.DepthFirstSearch;
import co.edu.redsegura.graph.DfsResult;
import co.edu.redsegura.graph.DijkstraSolver;
import co.edu.redsegura.graph.MixedGraph;
import co.edu.redsegura.graph.ShortestPathResult;
import co.edu.redsegura.graph.WeakComponents;
import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;
import co.edu.redsegura.trees.AvlTree;
import co.edu.redsegura.trees.BinarySearchTree;
import co.edu.redsegura.trees.TreeSearchResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Pruebas JUnit 5 de los componentes y de la integración RedSegura.
 */
class RedSeguraTest {

    @Test
    @DisplayName("Dijkstra conserva la ruta de control S02 -> S01 -> S07 -> S08 con 24 minutos")
    void dijkstraControlRouteTest() {
        RedSeguraCore core = new RedSeguraCore();
        ShortestPathResult result = core.shortestPath("S02", "S08");

        assertTrue(result.isReachable());
        assertEquals(24, result.getMinutes());
        assertArrayEquals(new String[]{"S02", "S01", "S07", "S08"}, result.getVertexIds());
        assertArrayEquals(new String[]{"R04", "R01", "R16"}, result.getEdgeIds());
    }

    @Test
    @DisplayName("Al bloquear R16 se reconstruye una ruta alternativa y el grafo original no cambia")
    void blockedEdgeTest() {
        RedSeguraCore core = new RedSeguraCore();
        ShortestPathResult blocked = core.shortestPathAvoidingEdge("S02", "S08", "R16");

        assertTrue(blocked.isReachable());
        assertEquals(24, blocked.getMinutes());
        assertArrayEquals(new String[]{"S02", "S01", "S09", "S10", "S08"},
                blocked.getVertexIds());
        assertTrue(core.hasConnection("R16"));

        MixedGraph copy = DataFactory.createGraph();
        assertTrue(copy.removeEdge("r16"));
        assertFalse(copy.hasEdge("R16"));
    }

    @Test
    @DisplayName("AVL demuestra LL, RR, LR y RL y permanece balanceado tras eliminaciones")
    void avlBalanceTest() {
        assertRotation("LL", new String[]{"30", "20", "10"});
        assertRotation("RR", new String[]{"10", "20", "30"});
        assertRotation("LR", new String[]{"30", "10", "20"});
        assertRotation("RL", new String[]{"10", "30", "20"});

        AvlTree tree = new AvlTree();
        int[] keys = {50, 30, 70, 20, 40, 60, 80, 10, 25, 35, 45, 65, 75};
        for (int key : keys) {
            assertTrue(tree.insert(vertexFor(key)));
        }
        assertEquals(keys.length, tree.size());
        assertTrue(tree.isBalanced());

        assertTrue(tree.delete("70"));
        assertTrue(tree.delete("30"));
        assertTrue(tree.delete("10"));
        assertTrue(tree.delete("50"));
        assertEquals(keys.length - 4, tree.size());
        assertTrue(tree.isBalanced());
        assertNotNull(tree.search("40"));
        assertNull(tree.search("30"));
        assertTrue(tree.height() <= 4);
    }

    private void assertRotation(String expectedType, String[] keys) {
        AvlTree tree = new AvlTree();
        for (String key : keys) {
            assertTrue(tree.insert(new Vertex("K" + key, key, "Clave")));
        }
        assertTrue(tree.isBalanced());
        assertEquals(1, tree.height());
        assertEquals("10, 20, 30", tree.inOrder());
        AvlTree.RotationEvent[] events = tree.getRotations();
        assertEquals(1, events.length);
        assertEquals(expectedType, events[0].type());
        assertFalse(events[0].before().isEmpty());
        assertFalse(events[0].after().isEmpty());
    }

    @Test
    @DisplayName("ABB implementa búsqueda, recorridos y los tres casos de eliminación")
    void binarySearchTreeTest() {
        BinarySearchTree tree = new BinarySearchTree();
        int[] keys = {50, 30, 70, 20, 40, 60, 80};
        for (int key : keys) {
            assertTrue(tree.insert(vertexFor(key)));
        }
        assertFalse(tree.insert(vertexFor(50)));
        assertEquals(7, tree.size());
        assertEquals("20, 30, 40, 50, 60, 70, 80", tree.inOrder());
        assertEquals("50, 30, 20, 40, 70, 60, 80", tree.preOrder());
        assertEquals("20, 40, 30, 60, 80, 70, 50", tree.postOrder());

        TreeSearchResult found = tree.searchWithComparisons("40");
        assertTrue(found.isFound());
        assertEquals(3, found.comparisons());

        assertTrue(tree.delete("20"));
        assertTrue(tree.delete("30"));
        assertTrue(tree.delete("50"));
        assertFalse(tree.delete("999"));
        assertEquals("40, 60, 70, 80", tree.inOrder());
        assertEquals(4, tree.size());
    }

    @Test
    @DisplayName("Se validan vértices inexistentes, IDs duplicados y pesos inválidos")
    void validationTest() {
        MixedGraph graph = DataFactory.createGraph();

        assertThrows(NoSuchElementException.class, () -> graph.getVertex("S99"));
        assertThrows(IllegalArgumentException.class,
                () -> new Edge("RX", "S01", "S02", true, 0, "Peso cero"));
        assertThrows(IllegalArgumentException.class,
                () -> new Edge("RY", "S01", "S02", false, -3, "Peso negativo"));
        assertThrows(IllegalArgumentException.class,
                () -> new Edge("RZ", "S01", "S01", true, 4, "Bucle"));
        assertThrows(IllegalArgumentException.class,
                () -> new Vertex(" ", "Vacío", "Tipo"));
        assertThrows(IllegalArgumentException.class,
                () -> graph.addVertex(new Vertex("S01", "Duplicado", "Universidad")));
        assertThrows(NoSuchElementException.class,
                () -> graph.addEdge(new Edge("RX", "S01", "S99", true, 2, "Destino inexistente")));
        assertThrows(IllegalArgumentException.class,
                () -> graph.addEdge(new Edge("R01", "S01", "S02", true, 2, "ID duplicado")));

        BinarySearchTree bst = new BinarySearchTree();
        AvlTree avl = new AvlTree();
        assertThrows(IllegalArgumentException.class, () -> bst.search(" "));
        assertThrows(IllegalArgumentException.class, () -> avl.search(null));
    }

    @Test
    @DisplayName("Un grafo desconectado se maneja en BFS, DFS, componentes débiles y Dijkstra")
    void disconnectedGraphTest() {
        MixedGraph graph = new MixedGraph();
        graph.addVertex(new Vertex("V01", "A", "Prueba"));
        graph.addVertex(new Vertex("V02", "B", "Prueba"));
        graph.addVertex(new Vertex("V03", "C", "Prueba"));
        graph.addEdge(new Edge("E01", "V01", "V02", false, 2, "Conexión"));

        BfsResult bfs = new BreadthFirstSearch(graph).traverse("V01");
        assertEquals(2, bfs.visitedCount());
        assertFalse(bfs.wasVisited("V03"));

        DfsResult dfs = new DepthFirstSearch(graph).traverse("V01");
        assertEquals(2, dfs.visitedCount());
        assertFalse(dfs.wasVisited("V03"));
        assertFalse(dfs.hasCycle());

        WeakComponents components = new DepthFirstSearch(graph).weakComponents();
        assertEquals(2, components.count());

        ShortestPathResult unreachable = new DijkstraSolver(graph).solve("V01", "V03");
        assertFalse(unreachable.isReachable());
        assertEquals(-1, unreachable.getMinutes());
        assertEquals(0, unreachable.getVertexIds().length);
    }

    @Test
    @DisplayName("Las representaciones usan el mismo orden y respetan dirección y pesos")
    void representationsTest() {
        RedSeguraCore core = new RedSeguraCore();
        int[][] adjacency = core.weightedAdjacencyMatrix();
        int[][] incidence = core.incidenceMatrix();

        assertEquals(12, adjacency.length);
        assertEquals(12, adjacency[0].length);
        assertEquals(18, incidence.length);
        assertEquals(12, incidence[0].length);

        assertEquals(8, adjacency[1][0]);   // S02 <-> S01 (R04)
        assertEquals(8, adjacency[0][1]);
        assertEquals(10, adjacency[1][5]);  // S02 -> S06 (R05)
        assertEquals(0, adjacency[5][1]);   // S06 no tiene retorno directo
        assertEquals(12, adjacency[6][7]);  // S07 -> S08 (R16)
        assertArrayEquals(new String[]{"S01", "S06"}, DataFactory.createGraph().getNeighbors("S02"));

        assertEquals(1, incidence[0][0]);   // R01 origen S01
        assertEquals(-1, incidence[0][6]);  // R01 destino S07
        assertEquals(1, incidence[2][0]);   // R03 no dirigida S01
        assertEquals(1, incidence[2][8]);   // R03 no dirigida S09
        assertEquals(1, incidence[3][1]);   // R04 S02
        assertEquals(1, incidence[3][0]);   // R04 S01
    }

    @Test
    @DisplayName("BFS y DFS visitan todos los alcanzables y DFS detecta ciclos")
    void traversalsTest() {
        RedSeguraCore core = new RedSeguraCore();
        BfsResult bfs = core.bfsFrom("S02");
        DfsResult dfs = core.dfsFrom("S02");

        assertEquals(12, bfs.visitedCount());
        assertEquals("S02", bfs.parentOf("S01"));
        assertEquals(1, bfs.levelOf("S01"));
        assertEquals(2, bfs.levelOf("S07"));

        assertEquals(12, dfs.visitedCount());
        assertTrue(dfs.hasCycle());
        assertTrue(dfs.getBackEdges().length > 0);
        assertEquals(1, core.weakComponents().count());
    }

    @Test
    @DisplayName("La consulta de S99 produce una excepción controlada")
    void missingVertexTest() {
        RedSeguraCore core = new RedSeguraCore();
        NoSuchElementException exception = assertThrows(NoSuchElementException.class,
                () -> core.getVertex("S99"));
        assertTrue(exception.getMessage().contains("S99"));
    }

    private static Vertex vertexFor(int key) {
        String label = String.valueOf(key);
        return new Vertex("K" + label, label, "Clave");
    }
}
