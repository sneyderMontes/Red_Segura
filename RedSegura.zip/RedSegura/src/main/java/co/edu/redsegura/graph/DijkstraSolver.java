package co.edu.redsegura.graph;

import co.edu.redsegura.model.Vertex;

import java.util.NoSuchElementException;

/**
 * Algoritmo de Dijkstra implementado manualmente con un min-heap binario propio.
 *
 * <p>No se utiliza ninguna cola de prioridad ni estructura algorítmica de la
 * biblioteca estándar. Se aplican relajación de arcos, distancias mínimas y un
 * arreglo de predecesores para reconstruir el camino y las conexiones usadas.</p>
 *
 * <p>Complejidad temporal {@code O((V + E) log V)} con heap binario y
 * {@code O(V + E)} de espacio auxiliar.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class DijkstraSolver {

    private static final int INFINITE = Integer.MAX_VALUE;

    private final MixedGraph graph;

    public DijkstraSolver(MixedGraph graph) {
        if (graph == null) {
            throw new IllegalArgumentException("El grafo de Dijkstra no puede ser nulo.");
        }
        this.graph = graph;
    }

    /**
     * Calcula la ruta mínima entre dos vértices respetando la orientación.
     *
     * @param originId      vértice origen
     * @param destinationId vértice destino
     * @return distancia, camino de vértices y conexiones, o resultado no alcanzable
     * @throws NoSuchElementException si origen o destino no existen
     */
    public ShortestPathResult solve(String originId, String destinationId) {
        Vertex[] vertices = graph.getVertices();
        int origin = indexOf(vertices, originId);
        if (origin < 0) {
            throw new NoSuchElementException("No existe el vértice origen " + originId + ".");
        }
        int destination = indexOf(vertices, destinationId);
        if (destination < 0) {
            throw new NoSuchElementException("No existe el vértice destino " + destinationId + ".");
        }

        int n = vertices.length;
        int[] distance = new int[n];
        int[] previous = new int[n];
        String[] previousEdge = new String[n];
        boolean[] settled = new boolean[n];
        for (int i = 0; i < n; i++) {
            distance[i] = INFINITE;
            previous[i] = -1;
        }

        MinHeap heap = new MinHeap();
        distance[origin] = 0;
        heap.add(origin, 0);

        int[] settledOrder = new int[n];
        int settledCount = 0;

        while (!heap.isEmpty()) {
            MinHeap.Entry entry = heap.poll();
            int current = entry.vertexIndex;
            if (settled[current]) {
                continue;
            }
            settled[current] = true;
            settledOrder[settledCount++] = current;
            if (current == destination) {
                break;
            }

            MixedGraph.Arc[] arcs = graph.getOutgoingArcs(vertices[current].getId());
            for (MixedGraph.Arc arc : arcs) {
                int next = indexOf(vertices, arc.toId());
                if (next < 0 || settled[next]) {
                    continue;
                }
                long candidate = (long) distance[current] + arc.minutes();
                if (candidate < distance[next]) {
                    distance[next] = (int) candidate;
                    previous[next] = current;
                    previousEdge[next] = arc.edgeId();
                    heap.add(next, (int) candidate);
                }
            }
        }

        String[] settledIds = new String[settledCount];
        for (int i = 0; i < settledCount; i++) {
            settledIds[i] = vertices[settledOrder[i]].getId();
        }

        if (distance[destination] == INFINITE) {
            return new ShortestPathResult(vertices[origin].getId(), vertices[destination].getId(),
                    -1, false, new String[0], new String[0], new String[0], settledIds);
        }

        int pathLength = 0;
        int current = destination;
        while (current >= 0) {
            pathLength++;
            if (current == origin) {
                break;
            }
            current = previous[current];
        }

        int[] reversedVertices = new int[pathLength];
        String[] reversedEdges = new String[Math.max(0, pathLength - 1)];
        current = destination;
        for (int i = pathLength - 1; i >= 0; i--) {
            reversedVertices[i] = current;
            if (i > 0) {
                reversedEdges[i - 1] = previousEdge[current];
            }
            current = previous[current];
        }

        String[] pathIds = new String[pathLength];
        String[] pathLabels = new String[pathLength];
        for (int i = 0; i < pathLength; i++) {
            pathIds[i] = vertices[reversedVertices[i]].getId();
            pathLabels[i] = vertices[reversedVertices[i]].getLabel();
        }

        return new ShortestPathResult(vertices[origin].getId(), vertices[destination].getId(),
                distance[destination], true, pathIds, pathLabels, reversedEdges, settledIds);
    }

    private static int indexOf(Vertex[] vertices, String id) {
        if (id == null) {
            return -1;
        }
        String normalized = id.trim();
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getId().equalsIgnoreCase(normalized)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Min-heap binario manual. Se permiten entradas duplicadas (lazy deletion):
     * al extraer una entrada de un vértice ya asentado se descarta.
     */
    private static final class MinHeap {
        private Entry[] data = new Entry[16];
        private int size;

        private void add(int vertexIndex, int distance) {
            if (size == data.length) {
                Entry[] larger = new Entry[data.length * 2];
                System.arraycopy(data, 0, larger, 0, data.length);
                data = larger;
            }
            data[size] = new Entry(vertexIndex, distance);
            siftUp(size);
            size++;
        }

        private Entry poll() {
            if (size == 0) {
                throw new IllegalStateException("No se puede extraer de un heap vacío.");
            }
            Entry result = data[0];
            size--;
            if (size > 0) {
                data[0] = data[size];
                siftDown(0);
            }
            data[size] = null;
            return result;
        }

        private boolean isEmpty() {
            return size == 0;
        }

        private void siftUp(int index) {
            while (index > 0) {
                int parent = (index - 1) / 2;
                if (data[parent].distance <= data[index].distance) {
                    break;
                }
                swap(parent, index);
                index = parent;
            }
        }

        private void siftDown(int index) {
            while (true) {
                int left = index * 2 + 1;
                int right = left + 1;
                int smallest = index;
                if (left < size && data[left].distance < data[smallest].distance) {
                    smallest = left;
                }
                if (right < size && data[right].distance < data[smallest].distance) {
                    smallest = right;
                }
                if (smallest == index) {
                    break;
                }
                swap(index, smallest);
                index = smallest;
            }
        }

        private void swap(int first, int second) {
            Entry temporary = data[first];
            data[first] = data[second];
            data[second] = temporary;
        }

        private static final class Entry {
            private final int vertexIndex;
            private final int distance;

            private Entry(int vertexIndex, int distance) {
                this.vertexIndex = vertexIndex;
                this.distance = distance;
            }
        }
    }
}
