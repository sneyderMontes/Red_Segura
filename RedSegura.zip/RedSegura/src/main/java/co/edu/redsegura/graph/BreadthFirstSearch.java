package co.edu.redsegura.graph;

import co.edu.redsegura.model.Vertex;

import java.util.NoSuchElementException;

/**
 * Búsqueda en anchura (BFS) implementada manualmente.
 *
 * <p>Usa una cola circular propia y un arreglo de visitados. Recorre únicamente
 * arcos salientes, por lo que respeta la orientación del grafo mixto. Complejidad
 * temporal {@code O(V + E)} y espacial {@code O(V)}.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class BreadthFirstSearch {

    private final MixedGraph graph;

    public BreadthFirstSearch(MixedGraph graph) {
        if (graph == null) {
            throw new IllegalArgumentException("El grafo del BFS no puede ser nulo.");
        }
        this.graph = graph;
    }

    /**
     * Recorre el grafo desde un vértice.
     *
     * @param startId vértice inicial
     * @return orden, niveles y árbol de padres del recorrido
     * @throws NoSuchElementException si el vértice no existe
     */
    public BfsResult traverse(String startId) {
        Vertex[] vertices = graph.getVertices();
        int start = indexOf(vertices, startId);
        if (start < 0) {
            throw new NoSuchElementException("No existe el vértice inicial " + startId + " para BFS.");
        }

        int n = vertices.length;
        boolean[] visited = new boolean[n];
        int[] parentIndex = new int[n];
        int[] level = new int[n];
        for (int i = 0; i < n; i++) {
            parentIndex[i] = -1;
            level[i] = -1;
        }

        int[] orderIndex = new int[n];
        int orderCount = 0;
        IntQueue queue = new IntQueue(n);

        visited[start] = true;
        level[start] = 0;
        queue.enqueue(start);

        while (!queue.isEmpty()) {
            int current = queue.dequeue();
            orderIndex[orderCount++] = current;
            MixedGraph.Arc[] arcs = graph.getOutgoingArcs(vertices[current].getId());
            for (MixedGraph.Arc arc : arcs) {
                int destination = indexOf(vertices, arc.toId());
                if (destination >= 0 && !visited[destination]) {
                    visited[destination] = true;
                    parentIndex[destination] = current;
                    level[destination] = level[current] + 1;
                    queue.enqueue(destination);
                }
            }
        }

        String[] order = new String[orderCount];
        String[] parents = new String[orderCount];
        int[] levels = new int[orderCount];
        for (int i = 0; i < orderCount; i++) {
            int vertexIndex = orderIndex[i];
            order[i] = vertices[vertexIndex].getId();
            int parent = parentIndex[vertexIndex];
            parents[i] = parent < 0 ? null : vertices[parent].getId();
            levels[i] = level[vertexIndex];
        }
        return new BfsResult(vertices[start].getId(), order, parents, levels);
    }

    private static int indexOf(Vertex[] vertices, String id) {
        if (id == null) {
            return -1;
        }
        String normalized = id.trim();
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getId().equalsIgnoreCase(normalized)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Cola circular manual para BFS.
     */
    private static final class IntQueue {
        private final int[] data;
        private int head;
        private int tail;
        private int size;

        private IntQueue(int capacity) {
            data = new int[Math.max(1, capacity)];
        }

        private void enqueue(int value) {
            if (size == data.length) {
                throw new IllegalStateException("Desbordamiento de la cola BFS.");
            }
            data[tail] = value;
            tail = (tail + 1) % data.length;
            size++;
        }

        private int dequeue() {
            if (size == 0) {
                throw new IllegalStateException("Cola BFS vacía.");
            }
            int value = data[head];
            head = (head + 1) % data.length;
            size--;
            return value;
        }

        private boolean isEmpty() {
            return size == 0;
        }
    }
}
