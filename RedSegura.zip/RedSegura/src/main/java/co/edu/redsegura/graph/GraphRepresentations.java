package co.edu.redsegura.graph;

import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;

/**
 * Genera las tres representaciones solicitadas del grafo mixto:
 * lista de adyacencia, matriz de adyacencia ponderada y matriz de incidencia.
 *
 * <p>Todas usan el mismo orden de vértices (orden de inserción) y el mismo orden
 * de conexiones. En la matriz de adyacencia, {@code 0} significa ausencia de
 * arco directo y los pesos positivos son minutos. Si existieran arcos paralelos,
 * se conserva el menor peso para esa celda; la lista y la incidencia conservan
 * todas las conexiones individuales.</p>
 *
 * <p>Convención de incidencia: arco dirigido = {@code +1} en origen y {@code -1}
 * en destino; arista no dirigida = {@code +1} en ambos extremos.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class GraphRepresentations {

    private final MixedGraph graph;

    /**
     * Crea el generador de representaciones.
     *
     * @param graph grafo a representar
     * @throws IllegalArgumentException si el grafo es nulo
     */
    public GraphRepresentations(MixedGraph graph) {
        if (graph == null) {
            throw new IllegalArgumentException("El grafo no puede ser nulo.");
        }
        this.graph = graph;
    }

    /**
     * Lista de adyacencia con arcos, pesos, IDs y etiquetas.
     *
     * @return texto listo para consola
     */
    public String adjacencyList() {
        StringBuilder result = new StringBuilder();
        result.append("LISTA DE ADYACENCIA (arcos salientes)\n");
        Vertex[] vertices = graph.getVertices();
        for (Vertex vertex : vertices) {
            result.append(vertex.getId()).append(" - ").append(vertex.getLabel()).append('\n');
            MixedGraph.Arc[] arcs = graph.getOutgoingArcs(vertex.getId());
            if (arcs.length == 0) {
                result.append("   (sin salidas)\n");
            } else {
                for (MixedGraph.Arc arc : arcs) {
                    result.append("   -> ").append(arc.toId())
                            .append(" | ").append(arc.edgeId())
                            .append(" | ").append(arc.minutes()).append(" min")
                            .append(" | ").append(arc.directed() ? "Dirigida" : "No dirigida")
                            .append(" | ").append(arc.label())
                            .append('\n');
                }
            }
        }
        return result.toString();
    }

    /**
     * Construye la matriz de adyacencia ponderada.
     *
     * @return matriz cuadrada de {@code n x n}
     */
    public int[][] weightedAdjacencyMatrix() {
        Vertex[] vertices = graph.getVertices();
        int n = vertices.length;
        int[][] matrix = new int[n][n];
        for (int origin = 0; origin < n; origin++) {
            MixedGraph.Arc[] arcs = graph.getOutgoingArcs(vertices[origin].getId());
            for (MixedGraph.Arc arc : arcs) {
                int destination = indexOf(vertices, arc.toId());
                if (destination >= 0) {
                    int current = matrix[origin][destination];
                    if (current == 0 || arc.minutes() < current) {
                        matrix[origin][destination] = arc.minutes();
                    }
                }
            }
        }
        return matrix;
    }

    /**
     * Construye la matriz de incidencia.
     *
     * @return matriz de {@code m conexiones x n vértices}
     */
    public int[][] incidenceMatrix() {
        Vertex[] vertices = graph.getVertices();
        Edge[] edges = graph.getEdges();
        int[][] matrix = new int[edges.length][vertices.length];
        for (int row = 0; row < edges.length; row++) {
            Edge edge = edges[row];
            int origin = indexOf(vertices, edge.getOriginId());
            int destination = indexOf(vertices, edge.getDestinationId());
            if (edge.isDirected()) {
                matrix[row][origin] = 1;
                matrix[row][destination] = -1;
            } else {
                matrix[row][origin] = 1;
                matrix[row][destination] = 1;
            }
        }
        return matrix;
    }

    /**
     * Matriz de adyacencia formateada con IDs de fila y columna.
     *
     * @return texto alineado para consola
     */
    public String adjacencyMatrixAsText() {
        Vertex[] vertices = graph.getVertices();
        int[][] matrix = weightedAdjacencyMatrix();
        StringBuilder result = new StringBuilder();
        result.append("MATRIZ DE ADYACENCIA PONDERADA (minutos; 0 = sin arco directo)\n");
        result.append("      ");
        for (Vertex vertex : vertices) {
            result.append(String.format("%6s", vertex.getId()));
        }
        result.append('\n');
        for (int row = 0; row < vertices.length; row++) {
            result.append(String.format("%-6s", vertices[row].getId()));
            for (int column = 0; column < vertices.length; column++) {
                result.append(String.format("%6d", matrix[row][column]));
            }
            result.append('\n');
        }
        return result.toString();
    }

    /**
     * Matriz de incidencia formateada con IDs de fila y columna.
     *
     * @return texto alineado para consola
     */
    public String incidenceMatrixAsText() {
        Vertex[] vertices = graph.getVertices();
        Edge[] edges = graph.getEdges();
        int[][] matrix = incidenceMatrix();
        StringBuilder result = new StringBuilder();
        result.append("MATRIZ DE INCIDENCIA (+1 origen/no dirigido, -1 destino dirigido)\n");
        result.append("      ");
        for (Vertex vertex : vertices) {
            result.append(String.format("%5s", vertex.getId()));
        }
        result.append('\n');
        for (int row = 0; row < edges.length; row++) {
            result.append(String.format("%-6s", edges[row].getId()));
            for (int column = 0; column < vertices.length; column++) {
                result.append(String.format("%5d", matrix[row][column]));
            }
            result.append('\n');
        }
        return result.toString();
    }

    private static int indexOf(Vertex[] vertices, String id) {
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getId().equalsIgnoreCase(id)) {
                return i;
            }
        }
        return -1;
    }
}
