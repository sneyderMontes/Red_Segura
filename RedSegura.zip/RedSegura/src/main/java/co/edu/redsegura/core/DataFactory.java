package co.edu.redsegura.core;

import co.edu.redsegura.graph.MixedGraph;
import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;

/**
 * Fábrica con el conjunto de datos didácticos oficial de RedSegura Sincelejo.
 *
 * <p>Contiene exactamente 12 vértices (S01..S12) y 18 conexiones (R01..R18).
 * Los pesos son tiempos de simulación y no información oficial de tránsito.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class DataFactory {

    private DataFactory() {
        // Clase utilitaria.
    }

    /**
     * Crea los 12 lugares del caso de estudio.
     *
     * @return arreglo de vértices en el orden S01..S12
     */
    public static Vertex[] createVertices() {
        return new Vertex[]{
                new Vertex("S01", "UAJS Sede C", "Universidad"),
                new Vertex("S02", "UAJS Sede E", "Universidad"),
                new Vertex("S03", "Universidad de Sucre", "Universidad"),
                new Vertex("S04", "CECAR", "Universidad"),
                new Vertex("S05", "Hospital Universitario", "Salud"),
                new Vertex("S06", "Clínica Las Américas", "Salud"),
                new Vertex("S07", "Estación Central SETP", "Transporte"),
                new Vertex("S08", "Terminal de Transporte", "Transporte"),
                new Vertex("S09", "Parque Santander", "Punto de encuentro"),
                new Vertex("S10", "Mercado de Sincelejo", "Comercio"),
                new Vertex("S11", "PEP Argelia", "Paradero"),
                new Vertex("S12", "Glorieta Sincelejito", "Movilidad")
        };
    }

    /**
     * Crea las 18 conexiones del caso de estudio.
     *
     * @return arreglo de conexiones en el orden R01..R18
     */
    public static Edge[] createEdges() {
        return new Edge[]{
                new Edge("R01", "S01", "S07", true, 4, "Corredor universitario"),
                new Edge("R02", "S07", "S01", true, 6, "Retorno por vía alterna"),
                new Edge("R03", "S01", "S09", false, 5, "Corredor peatonal"),
                new Edge("R04", "S02", "S01", false, 8, "Conexión entre sedes"),
                new Edge("R05", "S02", "S06", true, 10, "Ruta de atención"),
                new Edge("R06", "S06", "S05", true, 4, "Corredor clínico"),
                new Edge("R07", "S05", "S09", false, 6, "Vía hospitalaria"),
                new Edge("R08", "S09", "S10", false, 3, "Centro histórico"),
                new Edge("R09", "S10", "S08", true, 8, "Salida al terminal"),
                new Edge("R10", "S08", "S10", true, 9, "Ingreso desde terminal"),
                new Edge("R11", "S03", "S12", false, 4, "Corredor Puerta Roja"),
                new Edge("R12", "S12", "S09", false, 7, "Troncal al centro"),
                new Edge("R13", "S04", "S11", false, 6, "Conexión universitaria"),
                new Edge("R14", "S11", "S07", true, 8, "Ruta SETP al centro"),
                new Edge("R15", "S07", "S09", false, 3, "Transferencia central"),
                new Edge("R16", "S07", "S08", true, 12, "Ruta SETP al terminal"),
                new Edge("R17", "S09", "S03", true, 7, "Ruta hacia universidad"),
                new Edge("R18", "S12", "S04", true, 9, "Ruta hacia CECAR")
        };
    }

    /**
     * Construye el grafo con todos los vértices y conexiones oficiales.
     *
     * @return grafo mixto cargado
     */
    public static MixedGraph createGraph() {
        MixedGraph graph = new MixedGraph();
        for (Vertex vertex : createVertices()) {
            graph.addVertex(vertex);
        }
        for (Edge edge : createEdges()) {
            graph.addEdge(edge);
        }
        return graph;
    }

    /**
     * Busca una conexión del conjunto oficial por ID.
     *
     * @param edgeId ID de la conexión
     * @return conexión encontrada o {@code null}
     */
    public static Edge findEdge(String edgeId) {
        if (edgeId == null) {
            return null;
        }
        for (Edge edge : createEdges()) {
            if (edge.getId().equalsIgnoreCase(edgeId.trim())) {
                return edge;
            }
        }
        return null;
    }
}
