package co.edu.redsegura.app;

import co.edu.redsegura.core.RedSeguraCore;
import co.edu.redsegura.graph.BfsResult;
import co.edu.redsegura.graph.DfsResult;
import co.edu.redsegura.graph.ShortestPathResult;

import java.io.PrintStream;

/**
 * Medición breve y reproducible de las operaciones principales.
 *
 * <p>Los tiempos son indicativos y dependen del hardware, la JVM y la carga del
 * equipo. La utilidad no forma parte de los algoritmos: solo usa
 * {@link System#nanoTime()} para contrastar el análisis Big O.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class PerformanceProbe {

    private PerformanceProbe() {
        // Clase utilitaria.
    }

    /**
     * Ejecuta una medición con calentamiento previo de la JVM.
     *
     * @param core núcleo cargado
     * @param out  salida de consola
     */
    public static void run(RedSeguraCore core, PrintStream out) {
        if (core == null || out == null) {
            throw new IllegalArgumentException("El núcleo y la salida son obligatorios.");
        }
        final int searchIterations = 200_000;
        final int traversalIterations = 50_000;
        final int dijkstraIterations = 20_000;

        long sink = 0;
        for (int i = 0; i < 2_000; i++) {
            sink += core.searchPlace("Hospital Universitario").abb().comparisons();
        }

        long start = System.nanoTime();
        for (int i = 0; i < searchIterations; i++) {
            RedSeguraCore.TreeComparison comparison = core.searchPlace("Hospital Universitario");
            sink += comparison.abb().comparisons() + comparison.avl().comparisons();
        }
        long searchNanos = System.nanoTime() - start;

        for (int i = 0; i < 1_000; i++) {
            sink += core.bfsFrom("S02").visitedCount();
            sink += core.dfsFrom("S02").visitedCount();
            sink += core.shortestPath("S02", "S08").getMinutes();
        }

        start = System.nanoTime();
        for (int i = 0; i < traversalIterations; i++) {
            BfsResult bfs = core.bfsFrom("S02");
            sink += bfs.visitedCount();
        }
        long bfsNanos = System.nanoTime() - start;

        start = System.nanoTime();
        for (int i = 0; i < traversalIterations; i++) {
            DfsResult dfs = core.dfsFrom("S02");
            sink += dfs.visitedCount();
        }
        long dfsNanos = System.nanoTime() - start;

        start = System.nanoTime();
        for (int i = 0; i < dijkstraIterations; i++) {
            ShortestPathResult route = core.shortestPath("S02", "S08");
            sink += route.getMinutes();
        }
        long dijkstraNanos = System.nanoTime() - start;

        out.println("\n=== Medición breve de rendimiento (valores indicativos) ===");
        printResult(out, "Búsqueda ABB + AVL", searchNanos, searchIterations);
        printResult(out, "BFS desde S02", bfsNanos, traversalIterations);
        printResult(out, "DFS desde S02", dfsNanos, traversalIterations);
        printResult(out, "Dijkstra S02 -> S08", dijkstraNanos, dijkstraIterations);
        out.println("Checksum de control: " + sink);
        out.println("Repita con: java -jar target/redsegura-sincelejo-1.0.0.jar --benchmark");
    }

    private static void printResult(PrintStream out, String operation, long nanos, int iterations) {
        double nanosecondsPerOperation = (double) nanos / iterations;
        double millisecondsPerOperation = nanosecondsPerOperation / 1_000_000.0;
        out.printf("%-24s %10.1f ns/op  |  %8.4f ms/op  |  %d iteraciones%n",
                operation, nanosecondsPerOperation, millisecondsPerOperation, iterations);
    }
}
