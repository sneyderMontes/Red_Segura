package co.edu.redsegura.graph;

import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;

import java.util.NoSuchElementException;

/**
 * Grafo mixto etiquetado y ponderado, implementado con arreglos dinámicos y
 * listas enlazadas de adyacencia propias.
 *
 * <p>Las aristas no dirigidas generan dos arcos de recorrido (ida y vuelta) que
 * comparten el mismo ID de conexión. Los arcos dirigidos generan un único arco.
 * Los algoritmos de búsqueda siempre consumen {@link #getOutgoingArcs(String)},
 * por lo que respetan la orientación.</p>
 *
 * <p>Se validan IDs duplicados, vértices inexistentes y conexiones nulas.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class MixedGraph {

    private Vertex[] vertices = new Vertex[16];
    private int vertexCount;
    private Edge[] edges = new Edge[24];
    private int edgeCount;
    private ArcNode[] heads = new ArcNode[16];

    /**
     * Agrega un vértice al grafo.
     *
     * @param vertex vértice a agregar
     * @throws IllegalArgumentException si el vértice es nulo o su ID ya existe
     */
    public void addVertex(Vertex vertex) {
        if (vertex == null) {
            throw new IllegalArgumentException("No se puede agregar un vértice nulo.");
        }
        if (findVertex(vertex.getId()) != null) {
            throw new IllegalArgumentException("Ya existe un vértice con el ID " + vertex.getId() + ".");
        }
        if (vertexCount == vertices.length) {
            Vertex[] larger = new Vertex[vertices.length * 2];
            System.arraycopy(vertices, 0, larger, 0, vertices.length);
            vertices = larger;
            ArcNode[] largerHeads = new ArcNode[heads.length * 2];
            System.arraycopy(heads, 0, largerHeads, 0, heads.length);
            heads = largerHeads;
        }
        vertices[vertexCount] = vertex;
        heads[vertexCount] = null;
        vertexCount++;
    }

    /**
     * Agrega una conexión y valida que sus extremos existan.
     *
     * @param edge conexión a agregar
     * @throws IllegalArgumentException si la conexión es nula o su ID ya existe
     * @throws NoSuchElementException   si el origen o el destino no existen
     */
    public void addEdge(Edge edge) {
        if (edge == null) {
            throw new IllegalArgumentException("No se puede agregar una conexión nula.");
        }
        if (findEdge(edge.getId()) != null) {
            throw new IllegalArgumentException("Ya existe una conexión con el ID " + edge.getId() + ".");
        }
        int originIndex = indexOf(edge.getOriginId());
        int destinationIndex = indexOf(edge.getDestinationId());
        if (originIndex < 0) {
            throw new NoSuchElementException("No existe el vértice origen " + edge.getOriginId()
                    + " para la conexión " + edge.getId() + ".");
        }
        if (destinationIndex < 0) {
            throw new NoSuchElementException("No existe el vértice destino " + edge.getDestinationId()
                    + " para la conexión " + edge.getId() + ".");
        }
        if (edgeCount == edges.length) {
            Edge[] larger = new Edge[edges.length * 2];
            System.arraycopy(edges, 0, larger, 0, edges.length);
            edges = larger;
        }
        edges[edgeCount++] = edge;
        addArc(originIndex, destinationIndex, edge);
        if (!edge.isDirected()) {
            addArc(destinationIndex, originIndex, edge);
        }
    }

    /**
     * Elimina una conexión y todos sus arcos de recorrido.
     *
     * @param edgeId ID de la conexión
     * @return {@code true} si existía y fue eliminada
     */
    public boolean removeEdge(String edgeId) {
        int edgeIndex = indexOfEdge(edgeId);
        if (edgeIndex < 0) {
            return false;
        }
        String canonicalId = edges[edgeIndex].getId();
        for (int i = 0; i < vertexCount; i++) {
            ArcNode previous = null;
            ArcNode current = heads[i];
            while (current != null) {
                if (current.arc.edgeId().equals(canonicalId)) {
                    if (previous == null) {
                        heads[i] = current.next;
                    } else {
                        previous.next = current.next;
                    }
                    current = current.next;
                } else {
                    previous = current;
                    current = current.next;
                }
            }
        }
        for (int i = edgeIndex; i < edgeCount - 1; i++) {
            edges[i] = edges[i + 1];
        }
        edges[edgeCount - 1] = null;
        edgeCount--;
        return true;
    }

    /**
     * Obtiene un vértice por ID.
     *
     * @param vertexId ID solicitado
     * @return vértice encontrado
     * @throws NoSuchElementException si no existe
     */
    public Vertex getVertex(String vertexId) {
        Vertex vertex = findVertex(vertexId);
        if (vertex == null) {
            throw new NoSuchElementException("No existe el vértice " + vertexId + " en RedSegura.");
        }
        return vertex;
    }

    /**
     * Busca un vértice sin lanzar excepción.
     *
     * @param vertexId ID solicitado
     * @return vértice o {@code null}
     */
    public Vertex findVertex(String vertexId) {
        if (vertexId == null) {
            return null;
        }
        String normalized = vertexId.trim();
        for (int i = 0; i < vertexCount; i++) {
            if (vertices[i].getId().equalsIgnoreCase(normalized)) {
                return vertices[i];
            }
        }
        return null;
    }

    /**
     * Busca una conexión sin lanzar excepción.
     *
     * @param edgeId ID solicitado
     * @return conexión o {@code null}
     */
    public Edge findEdge(String edgeId) {
        int index = indexOfEdge(edgeId);
        return index < 0 ? null : edges[index];
    }

    public boolean hasVertex(String vertexId) {
        return findVertex(vertexId) != null;
    }

    public boolean hasEdge(String edgeId) {
        return indexOfEdge(edgeId) >= 0;
    }

    /**
     * Devuelve los arcos salientes del vértice en el orden de inserción.
     *
     * @param vertexId vértice consultado
     * @return copia de los arcos de recorrido salientes
     * @throws NoSuchElementException si el vértice no existe
     */
    public Arc[] getOutgoingArcs(String vertexId) {
        int index = indexOf(vertexId);
        if (index < 0) {
            throw new NoSuchElementException("No existe el vértice " + vertexId + " en RedSegura.");
        }
        int count = 0;
        ArcNode current = heads[index];
        while (current != null) {
            count++;
            current = current.next;
        }
        Arc[] result = new Arc[count];
        current = heads[index];
        int position = 0;
        while (current != null) {
            result[position++] = current.arc;
            current = current.next;
        }
        return result;
    }

    /**
     * Consulta los vecinos alcanzables directamente desde un vértice.
     *
     * @param vertexId vértice consultado
     * @return IDs de los destinos de sus arcos salientes
     * @throws NoSuchElementException si el vértice no existe
     */
    public String[] getNeighbors(String vertexId) {
        Arc[] arcs = getOutgoingArcs(vertexId);
        String[] neighbors = new String[arcs.length];
        for (int i = 0; i < arcs.length; i++) {
            neighbors[i] = arcs[i].toId();
        }
        return neighbors;
    }

    /**
     * Copia profunda de la topología del grafo. Los vértices y las conexiones
     * son inmutables, por lo que una nueva instancia conserva la independencia
     * de la estructura.
     *
     * @return grafo independiente con el mismo orden de inserción
     */
    public MixedGraph copy() {
        MixedGraph copy = new MixedGraph();
        for (int i = 0; i < vertexCount; i++) {
            copy.addVertex(vertices[i]);
        }
        for (int i = 0; i < edgeCount; i++) {
            copy.addEdge(edges[i]);
        }
        return copy;
    }

    /**
     * Devuelve una copia del arreglo de vértices en orden de inserción.
     *
     * @return vértices del grafo
     */
    public Vertex[] getVertices() {
        Vertex[] result = new Vertex[vertexCount];
        System.arraycopy(vertices, 0, result, 0, vertexCount);
        return result;
    }

    /**
     * Devuelve una copia del arreglo de conexiones en orden de inserción.
     *
     * @return conexiones del grafo
     */
    public Edge[] getEdges() {
        Edge[] result = new Edge[edgeCount];
        System.arraycopy(edges, 0, result, 0, edgeCount);
        return result;
    }

    public int vertexCount() {
        return vertexCount;
    }

    public int edgeCount() {
        return edgeCount;
    }

    private void addArc(int fromIndex, int toIndex, Edge edge) {
        Arc arc = new Arc(edge.getId(), vertices[fromIndex].getId(), vertices[toIndex].getId(),
                edge.getMinutes(), edge.getLabel(), edge.isDirected());
        ArcNode node = new ArcNode(arc);
        if (heads[fromIndex] == null) {
            heads[fromIndex] = node;
            return;
        }
        ArcNode current = heads[fromIndex];
        while (current.next != null) {
            current = current.next;
        }
        current.next = node;
    }

    private int indexOf(String vertexId) {
        if (vertexId == null) {
            return -1;
        }
        String normalized = vertexId.trim();
        for (int i = 0; i < vertexCount; i++) {
            if (vertices[i].getId().equalsIgnoreCase(normalized)) {
                return i;
            }
        }
        return -1;
    }

    private int indexOfEdge(String edgeId) {
        if (edgeId == null) {
            return -1;
        }
        for (int i = 0; i < edgeCount; i++) {
            if (edges[i].getId().equalsIgnoreCase(edgeId.trim())) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Arco de recorrido. Para una conexión no dirigida existen dos arcos con el
     * mismo {@code edgeId}; para una dirigida existe un solo arco.
     *
     * @param edgeId   ID de la conexión original
     * @param fromId   extremo desde el cual se recorre
     * @param toId     extremo hacia el cual se recorre
     * @param minutes  peso en minutos
     * @param label    etiqueta de la conexión
     * @param directed orientación de la conexión original
     */
    public record Arc(String edgeId, String fromId, String toId, int minutes,
                      String label, boolean directed) {

        public String describe() {
            return edgeId + ": " + fromId + " -> " + toId + " (" + minutes + " min, " + label + ")";
        }
    }

    private static final class ArcNode {
        private final Arc arc;
        private ArcNode next;

        private ArcNode(Arc arc) {
            this.arc = arc;
        }
    }
}
