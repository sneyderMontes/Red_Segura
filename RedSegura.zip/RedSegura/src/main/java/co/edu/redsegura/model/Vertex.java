package co.edu.redsegura.model;

/**
 * Representa un lugar o nodo de la red RedSegura.
 *
 * <p>Un vértice es inmutable. Su identidad lógica es el {@code id}; la etiqueta
 * es el texto legible que se utiliza en los árboles y en la interfaz de consola.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class Vertex {

    private final String id;
    private final String label;
    private final String type;

    /**
     * Crea un vértice válido.
     *
     * @param id    identificador no vacío, por ejemplo {@code S05}
     * @param label etiqueta legible, por ejemplo {@code Hospital Universitario}
     * @param type  tipo de lugar, por ejemplo {@code Salud}
     * @throws IllegalArgumentException si algún dato es nulo o está en blanco
     */
    public Vertex(String id, String label, String type) {
        this.id = requireText(id, "El ID del vértice");
        this.label = requireText(label, "La etiqueta del vértice");
        this.type = requireText(type, "El tipo de vértice");
    }

    public String getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public String getType() {
        return type;
    }

    /**
     * Compara vértices por su identidad lógica (ID).
     *
     * @param other objeto a comparar
     * @return {@code true} si ambos representan el mismo ID
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Vertex)) {
            return false;
        }
        Vertex vertex = (Vertex) other;
        return id.equals(vertex.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return id + " - " + label + " (" + type + ")";
    }

    private static String requireText(String value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " no puede ser nulo.");
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " no puede estar vacío.");
        }
        return trimmed;
    }
}
