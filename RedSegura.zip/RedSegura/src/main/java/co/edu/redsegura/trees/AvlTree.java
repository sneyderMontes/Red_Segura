package co.edu.redsegura.trees;

import co.edu.redsegura.model.Vertex;

/**
 * Árbol AVL implementado manualmente, con alturas, factor de balance y
 * rotaciones explícitas LL, RR, LR y RL.
 *
 * <p>La clave de orden es la etiqueta del vértice. Cada nodo conserva su altura
 * en número de nodos (una hoja mide 1). La API pública expone la altura en
 * aristas para mantener la misma convención que el ABB: árbol vacío = -1,
 * hoja = 0.</p>
 *
 * <p>Cada rotación genera un {@link RotationEvent} con la estructura antes y
 * después, lo que permite demostrar Q2 sin alterar el algoritmo.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class AvlTree {

    private Node root;
    private int size;
    private RotationEvent[] rotationEvents = new RotationEvent[8];
    private int rotationCount;

    /**
     * Inserta un vértice y reequilibra el camino de inserción.
     *
     * @param vertex vértice a insertar
     * @return {@code true} si se insertó; {@code false} si la etiqueta ya existe
     * @throws IllegalArgumentException si el vértice es nulo
     */
    public boolean insert(Vertex vertex) {
        if (vertex == null) {
            throw new IllegalArgumentException("No se puede insertar un vértice nulo en el AVL.");
        }
        if (search(vertex.getLabel()) != null) {
            return false;
        }
        root = insertRecursive(root, vertex);
        size++;
        return true;
    }

    private Node insertRecursive(Node node, Vertex vertex) {
        if (node == null) {
            return new Node(vertex);
        }
        int comparison = compareKeys(vertex.getLabel(), node.vertex.getLabel());
        if (comparison < 0) {
            node.left = insertRecursive(node.left, vertex);
        } else if (comparison > 0) {
            node.right = insertRecursive(node.right, vertex);
        } else {
            return node;
        }
        updateHeight(node);
        return rebalance(node);
    }

    /**
     * Busca un vértice por etiqueta.
     *
     * @param label etiqueta a buscar
     * @return vértice encontrado o {@code null}
     * @throws IllegalArgumentException si la etiqueta es nula o vacía
     */
    public Vertex search(String label) {
        return searchWithComparisons(label).value();
    }

    /**
     * Busca una etiqueta y cuenta los nodos comparados.
     *
     * @param label etiqueta a buscar
     * @return resultado con el vértice y el número de comparaciones
     * @throws IllegalArgumentException si la etiqueta es nula o vacía
     */
    public TreeSearchResult searchWithComparisons(String label) {
        String key = normalizeKey(label);
        Node current = root;
        int comparisons = 0;
        while (current != null) {
            comparisons++;
            int comparison = compareKeys(key, current.vertex.getLabel());
            if (comparison == 0) {
                return new TreeSearchResult(key, current.vertex, comparisons);
            }
            current = comparison < 0 ? current.left : current.right;
        }
        return new TreeSearchResult(key, null, comparisons);
    }

    public boolean contains(String label) {
        return search(label) != null;
    }

    /**
     * Elimina un vértice por etiqueta y reequilibra todos los ancestros afectados.
     *
     * @param label etiqueta a eliminar
     * @return {@code true} si se eliminó; {@code false} si no existía
     * @throws IllegalArgumentException si la etiqueta es nula o vacía
     */
    public boolean delete(String label) {
        String key = normalizeKey(label);
        if (search(key) == null) {
            return false;
        }
        root = deleteRecursive(root, key);
        size--;
        return true;
    }

    private Node deleteRecursive(Node node, String key) {
        if (node == null) {
            return null;
        }
        int comparison = compareKeys(key, node.vertex.getLabel());
        if (comparison < 0) {
            node.left = deleteRecursive(node.left, key);
        } else if (comparison > 0) {
            node.right = deleteRecursive(node.right, key);
        } else {
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }
            Node successor = minimumNode(node.right);
            node.vertex = successor.vertex;
            node.right = deleteRecursive(node.right, successor.vertex.getLabel());
        }
        updateHeight(node);
        return rebalance(node);
    }

    private Node minimumNode(Node node) {
        Node current = node;
        while (current.left != null) {
            current = current.left;
        }
        return current;
    }

    /**
     * Altura del AVL medida en aristas.
     *
     * @return {@code -1} si está vacío; {@code 0} si solo tiene raíz
     */
    public int height() {
        return root == null ? -1 : root.height - 1;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return root == null;
    }

    /**
     * Factor de balance de un nodo: altura(izquierda) - altura(derecha).
     * Los valores válidos para un AVL son -1, 0 y 1.
     *
     * @param label etiqueta del nodo
     * @return factor de balance
     * @throws IllegalArgumentException si la etiqueta no existe
     */
    public int balanceFactorOf(String label) {
        Node node = findNode(root, normalizeKey(label));
        if (node == null) {
            throw new IllegalArgumentException("No existe la etiqueta " + label + " en el AVL.");
        }
        return balanceFactor(node);
    }

    /**
     * Verifica recursivamente la propiedad AVL.
     *
     * @return {@code true} si todos los nodos están balanceados
     */
    public boolean isBalanced() {
        return isBalanced(root);
    }

    private boolean isBalanced(Node node) {
        if (node == null) {
            return true;
        }
        if (Math.abs(balanceFactor(node)) > 1) {
            return false;
        }
        return isBalanced(node.left) && isBalanced(node.right);
    }

    /**
     * Recorrido in-orden.
     *
     * @return etiquetas separadas por coma y espacio
     */
    public String inOrder() {
        StringBuilder result = new StringBuilder();
        appendInOrder(root, result);
        return result.toString();
    }

    private void appendInOrder(Node node, StringBuilder result) {
        if (node == null) {
            return;
        }
        appendInOrder(node.left, result);
        appendKey(result, node.vertex.getLabel());
        appendInOrder(node.right, result);
    }

    /**
     * Recorrido pre-orden.
     *
     * @return etiquetas separadas por coma y espacio
     */
    public String preOrder() {
        StringBuilder result = new StringBuilder();
        appendPreOrder(root, result);
        return result.toString();
    }

    private void appendPreOrder(Node node, StringBuilder result) {
        if (node == null) {
            return;
        }
        appendKey(result, node.vertex.getLabel());
        appendPreOrder(node.left, result);
        appendPreOrder(node.right, result);
    }

    /**
     * Recorrido post-orden.
     *
     * @return etiquetas separadas por coma y espacio
     */
    public String postOrder() {
        StringBuilder result = new StringBuilder();
        appendPostOrder(root, result);
        return result.toString();
    }

    private void appendPostOrder(Node node, StringBuilder result) {
        if (node == null) {
            return;
        }
        appendPostOrder(node.left, result);
        appendPostOrder(node.right, result);
        appendKey(result, node.vertex.getLabel());
    }

    /**
     * Devuelve la estructura completa del árbol.
     *
     * @return representación gráfica simple
     */
    public String structure() {
        if (root == null) {
            return "(árbol vacío)";
        }
        return structure(root);
    }

    private String structure(Node node) {
        if (node == null) {
            return "(subárbol vacío)";
        }
        StringBuilder result = new StringBuilder();
        result.append(node.vertex.getLabel()).append('\n');
        appendChildren(node, "", result);
        return result.toString();
    }

    private void appendChildren(Node node, String prefix, StringBuilder result) {
        if (node.left != null) {
            boolean last = node.right == null;
            result.append(prefix).append(last ? "\\-- " : "+-- ")
                    .append(node.left.vertex.getLabel()).append('\n');
            appendChildren(node.left, prefix + (last ? "    " : "|   "), result);
        }
        if (node.right != null) {
            result.append(prefix).append("\\-- ")
                    .append(node.right.vertex.getLabel()).append('\n');
            appendChildren(node.right, prefix + "    ", result);
        }
    }

    /**
     * Rotaciones registradas desde la creación del árbol.
     *
     * @return copia del historial en orden de ocurrencia
     */
    public RotationEvent[] getRotations() {
        RotationEvent[] copy = new RotationEvent[rotationCount];
        System.arraycopy(rotationEvents, 0, copy, 0, rotationCount);
        return copy;
    }

    public void resetRotationHistory() {
        rotationEvents = new RotationEvent[8];
        rotationCount = 0;
    }

    public void clear() {
        root = null;
        size = 0;
        resetRotationHistory();
    }

    private Node rebalance(Node node) {
        int balance = balanceFactor(node);
        if (balance > 1) {
            if (balanceFactor(node.left) >= 0) {
                return rotateLL(node);
            }
            return rotateLR(node);
        }
        if (balance < -1) {
            if (balanceFactor(node.right) <= 0) {
                return rotateRR(node);
            }
            return rotateRL(node);
        }
        return node;
    }

    /**
     * Caso LL: el subárbol izquierdo está cargado a la izquierda.
     * Se corrige con una rotación simple a la derecha.
     */
    private Node rotateLL(Node node) {
        String before = structure(node);
        Node newRoot = rotateRightInternal(node);
        String after = structure(newRoot);
        registerRotation("LL", node.vertex.getLabel(), before, after);
        return newRoot;
    }

    /**
     * Caso RR: el subárbol derecho está cargado a la derecha.
     * Se corrige con una rotación simple a la izquierda.
     */
    private Node rotateRR(Node node) {
        String before = structure(node);
        Node newRoot = rotateLeftInternal(node);
        String after = structure(newRoot);
        registerRotation("RR", node.vertex.getLabel(), before, after);
        return newRoot;
    }

    /**
     * Caso LR: subárbol izquierdo cargado a la derecha.
     * Primero rotación izquierda sobre el hijo y luego derecha sobre el nodo.
     */
    private Node rotateLR(Node node) {
        String before = structure(node);
        node.left = rotateLeftInternal(node.left);
        Node newRoot = rotateRightInternal(node);
        String after = structure(newRoot);
        registerRotation("LR", node.vertex.getLabel(), before, after);
        return newRoot;
    }

    /**
     * Caso RL: subárbol derecho cargado a la izquierda.
     * Primero rotación derecha sobre el hijo y luego izquierda sobre el nodo.
     */
    private Node rotateRL(Node node) {
        String before = structure(node);
        node.right = rotateRightInternal(node.right);
        Node newRoot = rotateLeftInternal(node);
        String after = structure(newRoot);
        registerRotation("RL", node.vertex.getLabel(), before, after);
        return newRoot;
    }

    private Node rotateRightInternal(Node node) {
        Node newRoot = node.left;
        Node transferred = newRoot.right;
        newRoot.right = node;
        node.left = transferred;
        updateHeight(node);
        updateHeight(newRoot);
        return newRoot;
    }

    private Node rotateLeftInternal(Node node) {
        Node newRoot = node.right;
        Node transferred = newRoot.left;
        newRoot.left = node;
        node.right = transferred;
        updateHeight(node);
        updateHeight(newRoot);
        return newRoot;
    }

    private void registerRotation(String type, String pivot, String before, String after) {
        if (rotationCount == rotationEvents.length) {
            RotationEvent[] larger = new RotationEvent[rotationEvents.length * 2];
            System.arraycopy(rotationEvents, 0, larger, 0, rotationEvents.length);
            rotationEvents = larger;
        }
        rotationEvents[rotationCount++] = new RotationEvent(type, pivot, before, after);
    }

    private int balanceFactor(Node node) {
        if (node == null) {
            return 0;
        }
        return height(node.left) - height(node.right);
    }

    private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    private void updateHeight(Node node) {
        node.height = 1 + Math.max(height(node.left), height(node.right));
    }

    private Node findNode(Node node, String key) {
        Node current = node;
        while (current != null) {
            int comparison = compareKeys(key, current.vertex.getLabel());
            if (comparison == 0) {
                return current;
            }
            current = comparison < 0 ? current.left : current.right;
        }
        return null;
    }

    private static void appendKey(StringBuilder result, String key) {
        if (result.length() > 0) {
            result.append(", ");
        }
        result.append(key);
    }

    private static String normalizeKey(String label) {
        if (label == null) {
            throw new IllegalArgumentException("La etiqueta de búsqueda no puede ser nula.");
        }
        String key = label.trim();
        if (key.isEmpty()) {
            throw new IllegalArgumentException("La etiqueta de búsqueda no puede estar vacía.");
        }
        return key;
    }

    private static int compareKeys(String left, String right) {
        int comparison = left.compareToIgnoreCase(right);
        if (comparison != 0) {
            return comparison;
        }
        return left.compareTo(right);
    }

    /**
     * Evento de rotación con el estado del subárbol antes y después.
     *
     * @param type   LL, RR, LR o RL
     * @param pivot  etiqueta del nodo desbalanceado
     * @param before estructura antes de rotar
     * @param after  estructura después de rotar
     */
    public record RotationEvent(String type, String pivot, String before, String after) {

        public String describe() {
            return "Rotación " + type + " en el nodo \"" + pivot + "\"";
        }

        @Override
        public String toString() {
            return describe();
        }
    }

    private static final class Node {
        private Vertex vertex;
        private Node left;
        private Node right;
        private int height;

        private Node(Vertex vertex) {
            this.vertex = vertex;
            this.height = 1;
        }
    }
}
