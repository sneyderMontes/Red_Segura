package co.edu.redsegura.graph;

/**
 * Resultado de un recorrido DFS, incluyendo orden de descubrimiento, orden de
 * finalización, árbol DFS, detección de ciclos y arcos de retroceso.
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class DfsResult {

    private final String startId;
    private final String[] discoveryOrder;
    private final String[] parents;
    private final int[] depths;
    private final String[] finishOrder;
    private final String[] backEdges;
    private final boolean cycle;

    DfsResult(String startId, String[] discoveryOrder, String[] parents, int[] depths,
              String[] finishOrder, String[] backEdges, boolean cycle) {
        this.startId = startId;
        this.discoveryOrder = discoveryOrder.clone();
        this.parents = parents.clone();
        this.depths = depths.clone();
        this.finishOrder = finishOrder.clone();
        this.backEdges = backEdges.clone();
        this.cycle = cycle;
    }

    /**
     * Vértice desde el cual inició el recorrido.
     *
     * @return ID de la raíz DFS
     */
    public String getStartId() {
        return startId;
    }

    /**
     * Orden de descubrimiento.
     *
     * @return copia de IDs en pre-orden
     */
    public String[] getDiscoveryOrder() {
        return discoveryOrder.clone();
    }

    /**
     * Orden de finalización (post-orden).
     *
     * @return copia de IDs
     */
    public String[] getFinishOrder() {
        return finishOrder.clone();
    }

    /**
     * Arcos que cierran ciclos.
     *
     * @return descripciones de arcos de retroceso
     */
    public String[] getBackEdges() {
        return backEdges.clone();
    }

    /**
     * Indica si se detectó al menos un ciclo alcanzable.
     *
     * @return {@code true} si existe un arco hacia un vértice gris
     */
    public boolean hasCycle() {
        return cycle;
    }

    /**
     * Cantidad de vértices descubiertos.
     *
     * @return número de visitados
     */
    public int visitedCount() {
        return discoveryOrder.length;
    }

    /**
     * Profundidad de descubrimiento de un vértice.
     *
     * @param vertexId ID consultado
     * @return profundidad o {@code -1} si no fue visitado
     */
    public int depthOf(String vertexId) {
        int index = indexOf(vertexId);
        return index < 0 ? -1 : depths[index];
    }

    /**
     * Padre de un vértice en el árbol DFS.
     *
     * @param vertexId ID consultado
     * @return padre o {@code null}
     */
    public String parentOf(String vertexId) {
        int index = indexOf(vertexId);
        return index < 0 ? null : parents[index];
    }

    /**
     * Indica si un vértice fue alcanzado.
     *
     * @param vertexId ID consultado
     * @return {@code true} si pertenece al recorrido
     */
    public boolean wasVisited(String vertexId) {
        return indexOf(vertexId) >= 0;
    }

    /**
     * Orden de descubrimiento en una línea.
     *
     * @return IDs separados por flechas
     */
    public String orderText() {
        return join(discoveryOrder, " -> ");
    }

    /**
     * Orden de finalización en una línea.
     *
     * @return IDs separados por flechas
     */
    public String finishText() {
        return join(finishOrder, " -> ");
    }

    /**
     * Árbol DFS con padres y profundidades.
     *
     * @return texto con una línea por vértice
     */
    public String treeText() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < discoveryOrder.length; i++) {
            result.append(discoveryOrder[i]).append(" <- ")
                    .append(parents[i] == null ? "(raíz)" : parents[i])
                    .append(" [profundidad ").append(depths[i]).append("]\n");
        }
        return result.toString();
    }

    public String backEdgesText() {
        if (backEdges.length == 0) {
            return "(sin arcos de retroceso)";
        }
        return join(backEdges, "\n");
    }

    private int indexOf(String vertexId) {
        if (vertexId == null) {
            return -1;
        }
        for (int i = 0; i < discoveryOrder.length; i++) {
            if (discoveryOrder[i].equalsIgnoreCase(vertexId.trim())) {
                return i;
            }
        }
        return -1;
    }

    private static String join(String[] values, String separator) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                result.append(separator);
            }
            result.append(values[i]);
        }
        return result.toString();
    }
}
