package co.edu.redsegura.graph;

/**
 * Componentes débiles de un grafo mixto. Una componente débil ignora la
 * orientación de los arcos y agrupa vértices conectados por cualquier conexión.
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class WeakComponents {

    private final String[][] components;

    WeakComponents(String[][] components) {
        this.components = new String[components.length][];
        for (int i = 0; i < components.length; i++) {
            this.components[i] = components[i].clone();
        }
    }

    /**
     * Número de componentes débiles.
     *
     * @return cantidad de componentes
     */
    public int count() {
        return components.length;
    }

    /**
     * Componentes como arreglos de IDs.
     *
     * @return copia de las componentes
     */
    public String[][] getComponents() {
        String[][] copy = new String[components.length][];
        for (int i = 0; i < components.length; i++) {
            copy[i] = components[i].clone();
        }
        return copy;
    }

    /**
     * Describe cada componente con sus IDs separados por coma.
     *
     * @return texto listo para consola
     */
    public String describe() {
        if (components.length == 0) {
            return "(grafo vacío)";
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < components.length; i++) {
            result.append("Componente ").append(i + 1).append(": ");
            for (int j = 0; j < components[i].length; j++) {
                if (j > 0) {
                    result.append(", ");
                }
                result.append(components[i][j]);
            }
            result.append('\n');
        }
        return result.toString();
    }
}
