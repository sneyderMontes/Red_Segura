package co.edu.redsegura.graph;

/**
 * Resultado de un recorrido BFS. El orden y las profundidades corresponden al
 * descubrimiento de vértices desde una raíz; {@code parentOf} describe el árbol
 * BFS.
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class BfsResult {

    private final String startId;
    private final String[] order;
    private final String[] parents;
    private final int[] levels;

    BfsResult(String startId, String[] order, String[] parents, int[] levels) {
        this.startId = startId;
        this.order = order.clone();
        this.parents = parents.clone();
        this.levels = levels.clone();
    }

    /**
     * Vértice desde el cual inició el recorrido.
     *
     * @return ID de la raíz BFS
     */
    public String getStartId() {
        return startId;
    }

    /**
     * Orden de descubrimiento por niveles.
     *
     * @return copia del arreglo de IDs
     */
    public String[] getOrder() {
        return order.clone();
    }

    /**
     * Cantidad de vértices alcanzados.
     *
     * @return número de visitados
     */
    public int visitedCount() {
        return order.length;
    }

    /**
     * Nivel BFS de un vértice.
     *
     * @param vertexId ID consultado
     * @return nivel o {@code -1} si no fue visitado
     */
    public int levelOf(String vertexId) {
        int index = indexOf(vertexId);
        return index < 0 ? -1 : levels[index];
    }

    /**
     * Padre de un vértice en el árbol BFS.
     *
     * @param vertexId ID consultado
     * @return ID del padre, {@code null} para la raíz, o {@code null} si no fue visitado
     */
    public String parentOf(String vertexId) {
        int index = indexOf(vertexId);
        return index < 0 ? null : parents[index];
    }

    /**
     * Indica si un vértice fue alcanzado.
     *
     * @param vertexId ID consultado
     * @return {@code true} si pertenece al recorrido
     */
    public boolean wasVisited(String vertexId) {
        return indexOf(vertexId) >= 0;
    }

    /**
     * Orden BFS en una línea.
     *
     * @return IDs separados por flechas
     */
    public String orderText() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < order.length; i++) {
            if (i > 0) {
                result.append(" -> ");
            }
            result.append(order[i]);
        }
        return result.toString();
    }

    /**
     * Árbol BFS expresado como relación hijo &lt;- padre (nivel).
     *
     * @return texto con una línea por vértice visitado
     */
    public String treeText() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < order.length; i++) {
            result.append(order[i]).append(" <- ")
                    .append(parents[i] == null ? "(raíz)" : parents[i])
                    .append(" [nivel ").append(levels[i]).append("]\n");
        }
        return result.toString();
    }

    private int indexOf(String vertexId) {
        if (vertexId == null) {
            return -1;
        }
        for (int i = 0; i < order.length; i++) {
            if (order[i].equalsIgnoreCase(vertexId.trim())) {
                return i;
            }
        }
        return -1;
    }
}
