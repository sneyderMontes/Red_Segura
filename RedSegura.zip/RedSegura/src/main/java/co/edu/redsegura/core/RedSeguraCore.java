package co.edu.redsegura.core;

import co.edu.redsegura.graph.BfsResult;
import co.edu.redsegura.graph.BreadthFirstSearch;
import co.edu.redsegura.graph.DepthFirstSearch;
import co.edu.redsegura.graph.DfsResult;
import co.edu.redsegura.graph.DijkstraSolver;
import co.edu.redsegura.graph.GraphRepresentations;
import co.edu.redsegura.graph.MixedGraph;
import co.edu.redsegura.graph.ShortestPathResult;
import co.edu.redsegura.graph.WeakComponents;
import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;
import co.edu.redsegura.trees.AvlTree;
import co.edu.redsegura.trees.BinarySearchTree;
import co.edu.redsegura.trees.TreeSearchResult;

import java.util.NoSuchElementException;

/**
 * Controlador central de RedSegura.
 *
 * <p>Integra el ABB, el AVL y el grafo mixto mediante contratos públicos. La
 * aplicación de consola no accede a campos privados de los módulos: toda la
 * funcionalidad se ofrece a través de esta fachada.</p>
 *
 * <p>El grafo se carga con {@link DataFactory}; los árboles se indexan por la
 * etiqueta del vértice para responder Q1.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class RedSeguraCore {

    private final MixedGraph graph;
    private final BinarySearchTree abb;
    private final AvlTree avl;
    private final GraphRepresentations representations;

    /**
     * Crea el núcleo con los datos didácticos oficiales.
     */
    public RedSeguraCore() {
        graph = DataFactory.createGraph();
        abb = new BinarySearchTree();
        avl = new AvlTree();
        for (Vertex vertex : DataFactory.createVertices()) {
            abb.insert(vertex);
            avl.insert(vertex);
        }
        representations = new GraphRepresentations(graph);
    }

    /**
     * Busca una etiqueta en ambos árboles y devuelve las métricas de comparación.
     *
     * @param label etiqueta a buscar
     * @return resultados del ABB y del AVL
     */
    public TreeComparison searchPlace(String label) {
        return new TreeComparison(abb.searchWithComparisons(label), avl.searchWithComparisons(label));
    }

    public int abbHeight() {
        return abb.height();
    }

    public int avlHeight() {
        return avl.height();
    }

    public int abbSize() {
        return abb.size();
    }

    public int avlSize() {
        return avl.size();
    }

    /**
     * Recorre el grafo desde un vértice con BFS.
     *
     * @param startId vértice inicial
     * @return resultado del recorrido
     */
    public BfsResult bfsFrom(String startId) {
        return new BreadthFirstSearch(graph).traverse(startId);
    }

    /**
     * Recorre el grafo desde un vértice con DFS.
     *
     * @param startId vértice inicial
     * @return resultado del recorrido
     */
    public DfsResult dfsFrom(String startId) {
        return new DepthFirstSearch(graph).traverse(startId);
    }

    /**
     * Calcula las componentes débiles de todo el grafo.
     *
     * @return componentes que ignoran la orientación
     */
    public WeakComponents weakComponents() {
        return new DepthFirstSearch(graph).weakComponents();
    }

    /**
     * Calcula la ruta mínima entre dos lugares.
     *
     * @param originId      origen
     * @param destinationId destino
     * @return resultado de Dijkstra
     */
    public ShortestPathResult shortestPath(String originId, String destinationId) {
        return new DijkstraSolver(graph).solve(originId, destinationId);
    }

    /**
     * Calcula una ruta mínima bloqueando temporalmente una conexión en una copia
     * del grafo. El grafo principal no se modifica, lo que permite repetir la
     * demostración Q6 sin efectos laterales.
     *
     * @param originId      origen
     * @param destinationId destino
     * @param edgeId        conexión a bloquear
     * @return ruta mínima sin la conexión indicada
     * @throws NoSuchElementException si la conexión no existe
     */
    public ShortestPathResult shortestPathAvoidingEdge(String originId, String destinationId,
                                                       String edgeId) {
        MixedGraph copy = graph.copy();
        if (!copy.hasEdge(edgeId)) {
            throw new NoSuchElementException("No existe la conexión " + edgeId + " para bloquear.");
        }
        copy.removeEdge(edgeId);
        return new DijkstraSolver(copy).solve(originId, destinationId);
    }

    /**
     * Bloquea una conexión en el grafo principal.
     *
     * @param edgeId ID de la conexión
     * @return {@code true} si existía
     */
    public boolean blockConnection(String edgeId) {
        return graph.removeEdge(edgeId);
    }

    /**
     * Restaura una conexión oficial previamente bloqueada.
     *
     * @param edgeId ID de la conexión
     * @return {@code true} si se agregó; {@code false} si ya existía
     * @throws NoSuchElementException si el ID no pertenece al conjunto oficial
     */
    public boolean restoreConnection(String edgeId) {
        if (graph.hasEdge(edgeId)) {
            return false;
        }
        Edge edge = DataFactory.findEdge(edgeId);
        if (edge == null) {
            throw new NoSuchElementException("No existe la conexión oficial " + edgeId + ".");
        }
        graph.addEdge(edge);
        return true;
    }

    /**
     * Busca un vértice y propaga una excepción controlada si no existe.
     *
     * @param vertexId ID solicitado
     * @return vértice encontrado
     * @throws NoSuchElementException si no existe
     */
    public Vertex getVertex(String vertexId) {
        return graph.getVertex(vertexId);
    }

    public boolean hasConnection(String edgeId) {
        return graph.hasEdge(edgeId);
    }

    public int vertexCount() {
        return graph.vertexCount();
    }

    public int edgeCount() {
        return graph.edgeCount();
    }

    /**
     * Lista de adyacencia del grafo.
     *
     * @return texto listo para consola
     */
    public String adjacencyList() {
        return representations.adjacencyList();
    }

    /**
     * Matriz de adyacencia ponderada.
     *
     * @return matriz de enteros
     */
    public int[][] weightedAdjacencyMatrix() {
        return representations.weightedAdjacencyMatrix();
    }

    /**
     * Matriz de incidencia.
     *
     * @return matriz de enteros
     */
    public int[][] incidenceMatrix() {
        return representations.incidenceMatrix();
    }

    public String adjacencyMatrixAsText() {
        return representations.adjacencyMatrixAsText();
    }

    public String incidenceMatrixAsText() {
        return representations.incidenceMatrixAsText();
    }

    /**
     * Genera la demostración de las cuatro rotaciones AVL con secuencias de tres
     * claves. Cada evento incluye la estructura antes y después de rotar.
     *
     * @return reporte listo para consola
     */
    public String avlRotationDemo() {
        String[][] cases = {
                {"LL", "30", "20", "10"},
                {"RR", "10", "20", "30"},
                {"LR", "30", "10", "20"},
                {"RL", "10", "30", "20"}
        };
        StringBuilder result = new StringBuilder();
        result.append("DEMOSTRACIÓN DE ROTACIONES AVL\n");
        for (String[] currentCase : cases) {
            AvlTree tree = new AvlTree();
            result.append("\nCaso ").append(currentCase[0]).append(": insertar ")
                    .append(currentCase[1]).append(", ")
                    .append(currentCase[2]).append(", ")
                    .append(currentCase[3]).append('\n');
            for (int i = 1; i < currentCase.length; i++) {
                tree.insert(demoVertex(currentCase[i]));
            }
            result.append("Estado final tras el reequilibrio:\n");
            result.append(tree.structure());
            result.append("Recorrido in-orden: ").append(tree.inOrder())
                    .append(" | altura: ").append(tree.height())
                    .append(" | balanceado: ").append(tree.isBalanced()).append('\n');

            AvlTree.RotationEvent[] events = tree.getRotations();
            if (events.length == 0) {
                result.append("No se registró rotación (revise la secuencia).\n");
            } else {
                for (AvlTree.RotationEvent event : events) {
                    result.append(event.describe()).append('\n');
                    result.append("Estado antes de la rotación:\n").append(event.before());
                    result.append("Estado después de la rotación:\n").append(event.after());
                }
            }
        }
        return result.toString();
    }

    private static Vertex demoVertex(String key) {
        return new Vertex("K" + key, key, "Clave de demostración");
    }

    /**
     * Resultado comparativo de Q1.
     *
     * @param abb resultado de la búsqueda en el ABB
     * @param avl resultado de la búsqueda en el AVL
     */
    public record TreeComparison(TreeSearchResult abb, TreeSearchResult avl) {
    }
}
