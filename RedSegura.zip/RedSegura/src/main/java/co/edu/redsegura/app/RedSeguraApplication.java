package co.edu.redsegura.app;

import co.edu.redsegura.core.RedSeguraCore;
import co.edu.redsegura.graph.BfsResult;
import co.edu.redsegura.graph.DfsResult;
import co.edu.redsegura.graph.ShortestPathResult;
import co.edu.redsegura.graph.WeakComponents;
import co.edu.redsegura.trees.TreeSearchResult;

import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.NoSuchElementException;

/**
 * Aplicación de consola RedSegura.
 *
 * <p>Ejecuta las siete consultas obligatorias Q1..Q7 sobre el núcleo integrado.
 * Puede usarse de forma interactiva o en modo demostración con
 * {@code --demo}.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class RedSeguraApplication {

    private final RedSeguraCore core;
    private final PrintStream out;

    public RedSeguraApplication() {
        this(new RedSeguraCore(), System.out);
    }

    public RedSeguraApplication(RedSeguraCore core, PrintStream out) {
        if (core == null) {
            throw new IllegalArgumentException("El núcleo de RedSegura no puede ser nulo.");
        }
        if (out == null) {
            throw new IllegalArgumentException("La salida de RedSegura no puede ser nula.");
        }
        this.core = core;
        this.out = out;
    }

    public static void main(String[] args) {
        configureUtf8Console();
        RedSeguraApplication application = new RedSeguraApplication();
        boolean demo = false;
        boolean benchmark = false;
        int requestedQuery = 0;
        for (String argument : args) {
            if ("--demo".equalsIgnoreCase(argument) || "-d".equalsIgnoreCase(argument)) {
                demo = true;
            } else if ("--benchmark".equalsIgnoreCase(argument)) {
                benchmark = true;
            } else if (argument.matches("[1-7]")) {
                requestedQuery = Integer.parseInt(argument);
            }
        }

        if (demo) {
            application.runAllDemonstrations();
        } else if (benchmark) {
            PerformanceProbe.run(application.core, application.out);
        } else if (requestedQuery > 0) {
            application.runQuery(requestedQuery);
        } else {
            application.runInteractive();
        }
    }

    /**
     * Fuerza la salida de la consola en UTF-8.
     *
     * <p>Windows y algunos IDE (por ejemplo Apache NetBeans) decodifican la salida
     * con UTF-8 aunque la JVM escriba con el juego de caracteres del sistema. Al
     * sustituir {@code System.out} y {@code System.err} por flujos UTF-8, las
     * tildes, la eñe y los signos de apertura se muestran correctamente sin
     * exigir argumentos adicionales al ejecutar el programa.</p>
     */
    private static void configureUtf8Console() {
        try {
            System.setOut(new PrintStream(
                    new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8));
            System.setErr(new PrintStream(
                    new FileOutputStream(FileDescriptor.err), true, StandardCharsets.UTF_8));
        } catch (RuntimeException exception) {
            // Si el entorno restringe los descriptores estándar se conserva la salida original.
        }
    }

    /**
     * Inicia el menú interactivo.
     */
    public void runInteractive() {
        printHeader();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean running = true;
        while (running) {
            printMenu();
            try {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                String option = line.trim();
                if (option.isEmpty()) {
                    continue;
                }
                if ("0".equals(option)) {
                    running = false;
                    out.println("Sesión finalizada. RedSegura queda disponible.");
                } else if ("8".equals(option)) {
                    runAllDemonstrations();
                } else if ("9".equals(option)) {
                    PerformanceProbe.run(core, out);
                } else if (option.matches("[1-7]")) {
                    runQuery(Integer.parseInt(option));
                } else {
                    out.println("Opción inválida. Digite un número entre 0 y 9.");
                }
            } catch (IOException exception) {
                out.println("No fue posible leer la consola: " + exception.getMessage());
                running = false;
            } catch (RuntimeException exception) {
                out.println("Se controló un error sin cerrar la aplicación: " + exception.getMessage());
            }
        }
    }

    /**
     * Ejecuta todas las consultas obligatorias.
     */
    public void runAllDemonstrations() {
        printHeader();
        q1();
        q2();
        q3();
        q4();
        q5();
        q6();
        q7();
        out.println("\nFin de las demostraciones Q1..Q7.");
    }

    /**
     * Ejecuta una consulta específica.
     *
     * @param number número de Q1 a Q7
     */
    public void runQuery(int number) {
        switch (number) {
            case 1 -> q1();
            case 2 -> q2();
            case 3 -> q3();
            case 4 -> q4();
            case 5 -> q5();
            case 6 -> q6();
            case 7 -> q7();
            default -> out.println("Consulta inexistente: Q" + number);
        }
    }

    /**
     * Q1: búsqueda del Hospital Universitario en ABB y AVL, comparando pasos.
     */
    public void q1() {
        out.println("\n=== Q1. Búsqueda del Hospital Universitario en ABB y AVL ===");
        RedSeguraCore.TreeComparison comparison = core.searchPlace("Hospital Universitario");
        TreeSearchResult abb = comparison.abb();
        TreeSearchResult avl = comparison.avl();
        out.println("ABB: " + abb.describe());
        out.println("AVL: " + avl.describe());
        out.println("Altura del ABB: " + core.abbHeight() + " aristas | nodos: " + core.abbSize());
        out.println("Altura del AVL: " + core.avlHeight() + " aristas | nodos: " + core.avlSize());
        out.println("Comparación: el AVL puede reducir comparaciones al mantener altura O(log n);"
                + " el ABB depende del orden de inserción.");
    }

    /**
     * Q2: demostración de rotaciones LL, RR, LR y RL.
     */
    public void q2() {
        out.println("\n=== Q2. Rotaciones AVL LL, RR, LR y RL ===");
        out.print(core.avlRotationDemo());
    }

    /**
     * Q3: lista de adyacencia y matrices.
     */
    public void q3() {
        out.println("\n=== Q3. Representaciones del grafo ===");
        out.println(core.adjacencyList());
        out.println(core.adjacencyMatrixAsText());
        out.println(core.incidenceMatrixAsText());
        out.println("El mismo orden de vértices S01..S12 y de conexiones R01..R18 se usa en las tres representaciones.");
    }

    /**
     * Q4: BFS y DFS desde S02.
     */
    public void q4() {
        out.println("\n=== Q4. BFS y DFS desde S02 ===");
        BfsResult bfs = core.bfsFrom("S02");
        DfsResult dfs = core.dfsFrom("S02");

        out.println("BFS (cola, por niveles): " + bfs.orderText());
        out.println("Árbol BFS:");
        out.print(bfs.treeText());

        out.println("\nDFS (recursión, por profundidad): " + dfs.orderText());
        out.println("Orden de finalización DFS: " + dfs.finishText());
        out.println("¿Hay ciclo alcanzable desde S02? " + (dfs.hasCycle() ? "Sí" : "No"));
        if (dfs.hasCycle()) {
            out.println("Arcos de retroceso:\n" + dfs.backEdgesText());
        }
        WeakComponents components = core.weakComponents();
        out.println("Componentes débiles: " + components.count());
        out.print(components.describe());

        out.println("Diferencia: BFS explora primero todos los vecinos de un nivel y usa cola;"
                + " DFS profundiza por una rama y usa recursión. Ambos controlan visitados,"
                + " pero el orden depende de la lista de adyacencia y de la orientación de los arcos.");
    }

    /**
     * Q5: Dijkstra de S02 a S08.
     */
    public void q5() {
        out.println("\n=== Q5. Ruta mínima S02 -> S08 con Dijkstra ===");
        ShortestPathResult route = core.shortestPath("S02", "S08");
        printRoute(route);
        if (route.isReachable() && route.getMinutes() == 24) {
            out.println("Validación: la ruta de control cumple 24 minutos.");
        } else {
            out.println("Atención: la ruta no coincide con el resultado de control de 24 minutos.");
        }
    }

    /**
     * Q6: bloqueo de R16 y recálculo.
     */
    public void q6() {
        out.println("\n=== Q6. Bloqueo de R16 y recálculo S02 -> S08 ===");
        ShortestPathResult original = core.shortestPath("S02", "S08");
        out.println("Ruta original:");
        printRoute(original);

        ShortestPathResult blocked = core.shortestPathAvoidingEdge("S02", "S08", "R16");
        out.println("Ruta con R16 bloqueada (bloqueo aplicado sobre una copia para no alterar el grafo):");
        printRoute(blocked);

        out.println("Explicación: R16 era el arco directo S07 -> S08 de 12 minutos.");
        out.println("Al bloquearlo, Dijkstra busca una alternativa y reconstruye el camino con predecesores.");
        out.println("La ruta alternativa evita R16 y usa: " + blocked.edgePathText()
                + " (" + blocked.getMinutes() + " minutos).");
        out.println("El costo total puede coincidir, pero la secuencia de vértices y conexiones cambia;"
                + " por eso se reconstruye el camino con predecesores.");
    }

    /**
     * Q7: consulta de un vértice inexistente sin terminar el programa.
     */
    public void q7() {
        out.println("\n=== Q7. Consulta controlada de un vértice inexistente ===");
        try {
            core.getVertex("S99");
            out.println("Error lógico: S99 no debería existir.");
        } catch (NoSuchElementException exception) {
            out.println("Excepción controlada: " + exception.getMessage());
            out.println("La consulta falló de forma limpia y la aplicación continúa ejecutándose.");
        }
    }

    private void printRoute(ShortestPathResult route) {
        if (!route.isReachable()) {
            out.println("  No existe ruta entre " + route.getOriginId() + " y " + route.getDestinationId() + ".");
            return;
        }
        out.println("  Distancia mínima: " + route.getMinutes() + " minutos");
        out.println("  Camino: " + route.pathText());
        out.println("  Detalle: " + route.labelPathText());
        out.println("  Conexiones: " + route.edgePathText());
        out.println("  Orden de asentamiento: " + route.settledText());
    }

    private void printHeader() {
        out.println("============================================================");
        out.println(" REDSEGURA SINCELEJO - Estructura de Datos II");
        out.println(" ABB + AVL + grafo mixto + BFS + DFS + Dijkstra");
        out.println(" Datos didácticos de simulación, no información oficial");
        out.println("============================================================");
    }

    private void printMenu() {
        out.println("\nConsultas obligatorias:");
        out.println("  1. Q1 - Buscar Hospital Universitario en ABB y AVL");
        out.println("  2. Q2 - Demostrar rotaciones AVL LL, RR, LR y RL");
        out.println("  3. Q3 - Lista de adyacencia y matrices");
        out.println("  4. Q4 - BFS y DFS desde S02");
        out.println("  5. Q5 - Dijkstra S02 -> S08");
        out.println("  6. Q6 - Bloquear R16 y recalcular");
        out.println("  7. Q7 - Consultar un vértice inexistente");
        out.println("  8. Ejecutar Q1..Q7");
        out.println("  9. Medición breve de rendimiento");
        out.println("  0. Salir");
        out.print("Seleccione una opción: ");
        out.flush();
    }
}
