package co.edu.redsegura.trees;

import co.edu.redsegura.model.Vertex;

/**
 * Resultado de una búsqueda en un árbol, incluyendo el número de comparaciones
 * de clave realizadas.
 *
 * @param key         clave buscada, ya normalizada
 * @param value       vértice encontrado o {@code null} si no existe
 * @param comparisons número de nodos comparados durante la búsqueda
 */
public record TreeSearchResult(String key, Vertex value, int comparisons) {

    /**
     * Indica si la búsqueda encontró un valor.
     *
     * @return {@code true} cuando {@link #value()} no es nulo
     */
    public boolean isFound() {
        return value != null;
    }

    /**
     * Descripción breve para la consola.
     *
     * @return texto con clave, estado y comparaciones
     */
    public String describe() {
        if (isFound()) {
            return "encontrado en " + comparisons + " comparación(es): " + value;
        }
        return "no encontrado tras " + comparisons + " comparación(es)";
    }
}
