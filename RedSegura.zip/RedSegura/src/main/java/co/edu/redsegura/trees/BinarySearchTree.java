package co.edu.redsegura.trees;

import co.edu.redsegura.model.Vertex;

/**
 * Árbol binario de búsqueda (ABB) implementado manualmente con nodos y punteros.
 *
 * <p>La clave de orden es la etiqueta del vértice. La comparación ignora
 * mayúsculas/minúsculas y, en caso de empate, usa el orden natural para evitar
 * ambigüedades. No se utilizan colecciones ni árboles de la biblioteca estándar.</p>
 *
 * <p>Convención de altura: un árbol vacío tiene altura {@code -1} y una hoja
 * tiene altura {@code 0} (altura medida en número de aristas).</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class BinarySearchTree {

    private Node root;
    private int size;

    /**
     * Inserta un vértice usando su etiqueta como clave.
     *
     * @param vertex vértice a insertar
     * @return {@code true} si se insertó; {@code false} si la etiqueta ya existe
     * @throws IllegalArgumentException si el vértice es nulo
     */
    public boolean insert(Vertex vertex) {
        if (vertex == null) {
            throw new IllegalArgumentException("No se puede insertar un vértice nulo en el ABB.");
        }
        if (root == null) {
            root = new Node(vertex);
            size = 1;
            return true;
        }
        if (search(vertex.getLabel()) != null) {
            return false;
        }
        root = insertRecursive(root, vertex);
        size++;
        return true;
    }

    private Node insertRecursive(Node node, Vertex vertex) {
        if (node == null) {
            return new Node(vertex);
        }
        int comparison = compareKeys(vertex.getLabel(), node.vertex.getLabel());
        if (comparison < 0) {
            node.left = insertRecursive(node.left, vertex);
        } else if (comparison > 0) {
            node.right = insertRecursive(node.right, vertex);
        }
        return node;
    }

    /**
     * Busca un vértice por etiqueta.
     *
     * @param label etiqueta a buscar
     * @return vértice encontrado o {@code null}
     * @throws IllegalArgumentException si la etiqueta es nula o vacía
     */
    public Vertex search(String label) {
        return searchWithComparisons(label).value();
    }

    /**
     * Busca una etiqueta y cuenta cuántos nodos fueron comparados.
     *
     * @param label etiqueta a buscar
     * @return resultado con vértice, clave y número de comparaciones
     * @throws IllegalArgumentException si la etiqueta es nula o vacía
     */
    public TreeSearchResult searchWithComparisons(String label) {
        String key = normalizeKey(label);
        Node current = root;
        int comparisons = 0;
        while (current != null) {
            comparisons++;
            int comparison = compareKeys(key, current.vertex.getLabel());
            if (comparison == 0) {
                return new TreeSearchResult(key, current.vertex, comparisons);
            }
            current = comparison < 0 ? current.left : current.right;
        }
        return new TreeSearchResult(key, null, comparisons);
    }

    /**
     * Indica si existe una etiqueta en el árbol.
     *
     * @param label etiqueta a consultar
     * @return {@code true} si existe
     */
    public boolean contains(String label) {
        return search(label) != null;
    }

    /**
     * Elimina un vértice por etiqueta, cubriendo los casos de cero, uno y dos hijos.
     *
     * @param label etiqueta a eliminar
     * @return {@code true} si se eliminó; {@code false} si no existía
     * @throws IllegalArgumentException si la etiqueta es nula o vacía
     */
    public boolean delete(String label) {
        String key = normalizeKey(label);
        if (search(key) == null) {
            return false;
        }
        root = deleteRecursive(root, key);
        size--;
        return true;
    }

    private Node deleteRecursive(Node node, String key) {
        if (node == null) {
            return null;
        }
        int comparison = compareKeys(key, node.vertex.getLabel());
        if (comparison < 0) {
            node.left = deleteRecursive(node.left, key);
        } else if (comparison > 0) {
            node.right = deleteRecursive(node.right, key);
        } else {
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }
            Node successor = minimumNode(node.right);
            node.vertex = successor.vertex;
            node.right = deleteRecursive(node.right, successor.vertex.getLabel());
        }
        return node;
    }

    private Node minimumNode(Node node) {
        Node current = node;
        while (current.left != null) {
            current = current.left;
        }
        return current;
    }

    /**
     * Altura del árbol medida en aristas.
     *
     * @return {@code -1} si está vacío; {@code 0} si solo tiene raíz
     */
    public int height() {
        return heightOf(root) - 1;
    }

    private int heightOf(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + Math.max(heightOf(node.left), heightOf(node.right));
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return root == null;
    }

    /**
     * Recorrido in-orden (izquierda, raíz, derecha).
     *
     * @return etiquetas separadas por coma y espacio
     */
    public String inOrder() {
        StringBuilder result = new StringBuilder();
        appendInOrder(root, result);
        return result.toString();
    }

    private void appendInOrder(Node node, StringBuilder result) {
        if (node == null) {
            return;
        }
        appendInOrder(node.left, result);
        appendKey(result, node.vertex.getLabel());
        appendInOrder(node.right, result);
    }

    /**
     * Recorrido pre-orden (raíz, izquierda, derecha).
     *
     * @return etiquetas separadas por coma y espacio
     */
    public String preOrder() {
        StringBuilder result = new StringBuilder();
        appendPreOrder(root, result);
        return result.toString();
    }

    private void appendPreOrder(Node node, StringBuilder result) {
        if (node == null) {
            return;
        }
        appendKey(result, node.vertex.getLabel());
        appendPreOrder(node.left, result);
        appendPreOrder(node.right, result);
    }

    /**
     * Recorrido post-orden (izquierda, derecha, raíz).
     *
     * @return etiquetas separadas por coma y espacio
     */
    public String postOrder() {
        StringBuilder result = new StringBuilder();
        appendPostOrder(root, result);
        return result.toString();
    }

    private void appendPostOrder(Node node, StringBuilder result) {
        if (node == null) {
            return;
        }
        appendPostOrder(node.left, result);
        appendPostOrder(node.right, result);
        appendKey(result, node.vertex.getLabel());
    }

    /**
     * Devuelve una representación gráfica simple del árbol.
     *
     * @return estructura con conectores de texto
     */
    public String structure() {
        if (root == null) {
            return "(árbol vacío)";
        }
        StringBuilder result = new StringBuilder();
        result.append(root.vertex.getLabel()).append('\n');
        appendChildren(root, "", result);
        return result.toString();
    }

    private void appendChildren(Node node, String prefix, StringBuilder result) {
        if (node.left != null) {
            boolean last = node.right == null;
            result.append(prefix).append(last ? "\\-- " : "+-- ")
                    .append(node.left.vertex.getLabel()).append('\n');
            appendChildren(node.left, prefix + (last ? "    " : "|   "), result);
        }
        if (node.right != null) {
            result.append(prefix).append("\\-- ")
                    .append(node.right.vertex.getLabel()).append('\n');
            appendChildren(node.right, prefix + "    ", result);
        }
    }

    public void clear() {
        root = null;
        size = 0;
    }

    private static void appendKey(StringBuilder result, String key) {
        if (result.length() > 0) {
            result.append(", ");
        }
        result.append(key);
    }

    private static String normalizeKey(String label) {
        if (label == null) {
            throw new IllegalArgumentException("La etiqueta de búsqueda no puede ser nula.");
        }
        String key = label.trim();
        if (key.isEmpty()) {
            throw new IllegalArgumentException("La etiqueta de búsqueda no puede estar vacía.");
        }
        return key;
    }

    /**
     * Comparación estable para etiquetas: primero sin distinguir mayúsculas y
     * después con el orden natural para desempatar.
     */
    private static int compareKeys(String left, String right) {
        int comparison = left.compareToIgnoreCase(right);
        if (comparison != 0) {
            return comparison;
        }
        return left.compareTo(right);
    }

    private static final class Node {
        private Vertex vertex;
        private Node left;
        private Node right;

        private Node(Vertex vertex) {
            this.vertex = vertex;
        }
    }
}
