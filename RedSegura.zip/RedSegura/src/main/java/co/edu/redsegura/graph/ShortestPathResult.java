package co.edu.redsegura.graph;

/**
 * Resultado de una ruta mínima calculada con Dijkstra.
 *
 * <p>Si no existe ruta, {@link #isReachable()} es {@code false},
 * {@link #getMinutes()} devuelve {@code -1} y los arreglos de camino están
 * vacíos.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class ShortestPathResult {

    private final String originId;
    private final String destinationId;
    private final int minutes;
    private final boolean reachable;
    private final String[] vertexIds;
    private final String[] vertexLabels;
    private final String[] edgeIds;
    private final String[] settledOrder;

    ShortestPathResult(String originId, String destinationId, int minutes, boolean reachable,
                       String[] vertexIds, String[] vertexLabels, String[] edgeIds,
                       String[] settledOrder) {
        this.originId = originId;
        this.destinationId = destinationId;
        this.minutes = minutes;
        this.reachable = reachable;
        this.vertexIds = vertexIds.clone();
        this.vertexLabels = vertexLabels.clone();
        this.edgeIds = edgeIds.clone();
        this.settledOrder = settledOrder.clone();
    }

    /**
     * Origen de la consulta.
     *
     * @return ID de origen
     */
    public String getOriginId() {
        return originId;
    }

    /**
     * Destino de la consulta.
     *
     * @return ID de destino
     */
    public String getDestinationId() {
        return destinationId;
    }

    /**
     * Distancia mínima total.
     *
     * @return minutos, o {@code -1} si no hay ruta
     */
    public int getMinutes() {
        return minutes;
    }

    /**
     * Indica si el destino fue alcanzado.
     *
     * @return {@code true} si existe camino
     */
    public boolean isReachable() {
        return reachable;
    }

    /**
     * Camino reconstruido como IDs.
     *
     * @return copia del camino desde origen hasta destino
     */
    public String[] getVertexIds() {
        return vertexIds.clone();
    }

    /**
     * Etiquetas correspondientes a los vértices del camino.
     *
     * @return copia de etiquetas
     */
    public String[] getVertexLabels() {
        return vertexLabels.clone();
    }

    /**
     * IDs de las conexiones usadas por el camino.
     *
     * @return copia de IDs de conexiones
     */
    public String[] getEdgeIds() {
        return edgeIds.clone();
    }

    /**
     * Orden en el que Dijkstra asentó los vértices.
     *
     * @return copia del orden de asentamiento
     */
    public String[] getSettledOrder() {
        return settledOrder.clone();
    }

    /**
     * Camino en formato de IDs.
     *
     * @return secuencia con flechas o texto de no alcanzable
     */
    public String pathText() {
        if (!reachable) {
            return "(sin ruta)";
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < vertexIds.length; i++) {
            if (i > 0) {
                result.append(" -> ");
            }
            result.append(vertexIds[i]);
        }
        return result.toString();
    }

    /**
     * Camino en formato de IDs y etiquetas.
     *
     * @return detalle legible o texto de no alcanzable
     */
    public String labelPathText() {
        if (!reachable) {
            return "(sin ruta)";
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < vertexIds.length; i++) {
            if (i > 0) {
                result.append(" -> ");
            }
            result.append(vertexIds[i]).append(" (").append(vertexLabels[i]).append(')');
        }
        return result.toString();
    }

    /**
     * IDs de las conexiones usadas.
     *
     * @return secuencia de conexiones o texto sin conexiones
     */
    public String edgePathText() {
        if (!reachable || edgeIds.length == 0) {
            return "(sin conexiones)";
        }
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < edgeIds.length; i++) {
            if (i > 0) {
                result.append(" -> ");
            }
            result.append(edgeIds[i]);
        }
        return result.toString();
    }

    /**
     * Orden de asentamiento en una línea.
     *
     * @return IDs separados por coma
     */
    public String settledText() {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < settledOrder.length; i++) {
            if (i > 0) {
                result.append(", ");
            }
            result.append(settledOrder[i]);
        }
        return result.toString();
    }
}
