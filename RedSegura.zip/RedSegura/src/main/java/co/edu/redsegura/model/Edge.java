package co.edu.redsegura.model;

/**
 * Conexión ponderada y etiquetada entre dos vértices de RedSegura.
 *
 * <p>Una arista puede ser dirigida o no dirigida. El peso representa minutos
 * estimados de desplazamiento en la simulación y debe ser estrictamente mayor
 * que cero. La orientación se conserva en {@link #isDirected()}.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class Edge {

    private final String id;
    private final String originId;
    private final String destinationId;
    private final boolean directed;
    private final int minutes;
    private final String label;

    /**
     * Crea una conexión válida.
     *
     * @param id            identificador único, por ejemplo {@code R16}
     * @param originId      ID del vértice origen
     * @param destinationId ID del vértice destino
     * @param directed      {@code true} para arco dirigido; {@code false} para arista
     * @param minutes       peso positivo en minutos
     * @param label         etiqueta descriptiva de la conexión
     * @throws IllegalArgumentException si un texto es nulo/vacío, si el peso no es
     *                                  positivo o si origen y destino son iguales
     */
    public Edge(String id, String originId, String destinationId,
                boolean directed, int minutes, String label) {
        this.id = requireText(id, "El ID de la conexión");
        this.originId = requireText(originId, "El origen de la conexión");
        this.destinationId = requireText(destinationId, "El destino de la conexión");
        this.label = requireText(label, "La etiqueta de la conexión");
        if (this.originId.equals(this.destinationId)) {
            throw new IllegalArgumentException("Una conexión no puede tener el mismo origen y destino: "
                    + this.originId + ".");
        }
        if (minutes <= 0) {
            throw new IllegalArgumentException("El peso de la conexión " + this.id
                    + " debe ser mayor que cero (minutos recibidos: " + minutes + ").");
        }
        this.directed = directed;
        this.minutes = minutes;
    }

    public String getId() {
        return id;
    }

    public String getOriginId() {
        return originId;
    }

    public String getDestinationId() {
        return destinationId;
    }

    public boolean isDirected() {
        return directed;
    }

    public int getMinutes() {
        return minutes;
    }

    public String getLabel() {
        return label;
    }

    /**
     * Devuelve el tipo de orientación en español.
     *
     * @return {@code Dirigida} o {@code No dirigida}
     */
    public String getDirectionLabel() {
        return directed ? "Dirigida" : "No dirigida";
    }

    /**
     * Indica si este extremo participa en la conexión.
     *
     * @param vertexId ID a consultar
     * @return {@code true} si es origen o destino
     */
    public boolean touches(String vertexId) {
        return originId.equals(vertexId) || destinationId.equals(vertexId);
    }

    /**
     * Devuelve el extremo opuesto a un vértice de la conexión.
     *
     * @param vertexId uno de los dos extremos
     * @return el otro extremo
     * @throws IllegalArgumentException si el vértice no pertenece a la conexión
     */
    public String otherEnd(String vertexId) {
        if (originId.equals(vertexId)) {
            return destinationId;
        }
        if (destinationId.equals(vertexId)) {
            return originId;
        }
        throw new IllegalArgumentException("El vértice " + vertexId
                + " no pertenece a la conexión " + id + ".");
    }

    @Override
    public String toString() {
        String arrow = directed ? " -> " : " <-> ";
        return id + ": " + originId + arrow + destinationId
                + " [" + minutes + " min, " + getDirectionLabel() + ", " + label + "]";
    }

    private static String requireText(String value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " no puede ser nulo.");
        }
        String trimmed = value.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " no puede estar vacío.");
        }
        return trimmed;
    }
}
