package co.edu.redsegura.graph;

import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;

import java.util.NoSuchElementException;

/**
 * Búsqueda en profundidad (DFS) manual, recursiva, con control de visitados y
 * estados blanco/gris/negro para detectar ciclos.
 *
 * <p>Un arco hacia un vértice gris es un arco de retroceso y evidencia un ciclo.
 * En conexiones no dirigidas se omite el retorno directo por la misma conexión
 * padre, para no confundir una sola arista con un ciclo.</p>
 *
 * <p>También calcula componentes débiles tratando todas las conexiones como no
 * dirigidas. Complejidad temporal {@code O(V + E)} y espacial {@code O(V)}.</p>
 *
 * @author RedSegura
 * @since 1.0.0
 */
public final class DepthFirstSearch {

    private final MixedGraph graph;

    public DepthFirstSearch(MixedGraph graph) {
        if (graph == null) {
            throw new IllegalArgumentException("El grafo del DFS no puede ser nulo.");
        }
        this.graph = graph;
    }

    /**
     * Recorre en profundidad desde un vértice.
     *
     * @param startId vértice inicial
     * @return orden de descubrimiento, finalización, árbol DFS y ciclos
     * @throws NoSuchElementException si el vértice no existe
     */
    public DfsResult traverse(String startId) {
        Vertex[] vertices = graph.getVertices();
        int start = indexOf(vertices, startId);
        if (start < 0) {
            throw new NoSuchElementException("No existe el vértice inicial " + startId + " para DFS.");
        }

        int n = vertices.length;
        int[] state = new int[n];
        int[] parentIndex = new int[n];
        int[] depth = new int[n];
        for (int i = 0; i < n; i++) {
            parentIndex[i] = -1;
            depth[i] = -1;
        }

        int[] discoveryIndex = new int[n];
        int[] finishIndex = new int[n];
        String[] backEdges = new String[graph.edgeCount() * 2 + 1];
        int[] counters = new int[3];
        boolean[] cycleFound = new boolean[1];

        dfsVisit(start, null, 0, state, parentIndex, depth, discoveryIndex, finishIndex,
                backEdges, counters, cycleFound, vertices);

        String[] discovery = new String[counters[0]];
        String[] parents = new String[counters[0]];
        int[] depths = new int[counters[0]];
        for (int i = 0; i < counters[0]; i++) {
            int vertexIndex = discoveryIndex[i];
            discovery[i] = vertices[vertexIndex].getId();
            int parent = parentIndex[vertexIndex];
            parents[i] = parent < 0 ? null : vertices[parent].getId();
            depths[i] = depth[vertexIndex];
        }

        String[] finish = new String[counters[1]];
        for (int i = 0; i < counters[1]; i++) {
            finish[i] = vertices[finishIndex[i]].getId();
        }

        String[] effectiveBackEdges = new String[counters[2]];
        System.arraycopy(backEdges, 0, effectiveBackEdges, 0, counters[2]);

        return new DfsResult(vertices[start].getId(), discovery, parents, depths,
                finish, effectiveBackEdges, cycleFound[0]);
    }

    private void dfsVisit(int current, String parentEdgeId, int currentDepth,
                          int[] state, int[] parentIndex, int[] depth,
                          int[] discoveryIndex, int[] finishIndex,
                          String[] backEdges, int[] counters, boolean[] cycleFound,
                          Vertex[] vertices) {
        state[current] = 1;
        depth[current] = currentDepth;
        discoveryIndex[counters[0]++] = current;

        MixedGraph.Arc[] arcs = graph.getOutgoingArcs(vertices[current].getId());
        for (MixedGraph.Arc arc : arcs) {
            int destination = indexOf(vertices, arc.toId());
            if (destination < 0) {
                continue;
            }
            boolean isParentUndirectedReturn = parentEdgeId != null
                    && arc.edgeId().equals(parentEdgeId)
                    && destination == parentIndex[current];
            if (isParentUndirectedReturn) {
                continue;
            }
            if (state[destination] == 0) {
                parentIndex[destination] = current;
                dfsVisit(destination, arc.edgeId(), currentDepth + 1, state, parentIndex,
                        depth, discoveryIndex, finishIndex, backEdges, counters, cycleFound, vertices);
            } else if (state[destination] == 1) {
                cycleFound[0] = true;
                if (counters[2] < backEdges.length) {
                    backEdges[counters[2]++] = arc.edgeId() + ": "
                            + vertices[current].getId() + " -> " + vertices[destination].getId()
                            + " (retroceso)";
                }
            }
        }

        state[current] = 2;
        finishIndex[counters[1]++] = current;
    }

    /**
     * Calcula las componentes débiles de todo el grafo.
     *
     * @return componentes que ignoran la orientación de los arcos
     */
    public WeakComponents weakComponents() {
        Vertex[] vertices = graph.getVertices();
        int n = vertices.length;
        IntNode[] adjacency = new IntNode[n];

        for (Edge edge : graph.getEdges()) {
            int origin = indexOf(vertices, edge.getOriginId());
            int destination = indexOf(vertices, edge.getDestinationId());
            if (origin >= 0 && destination >= 0) {
                adjacency[origin] = new IntNode(destination, adjacency[origin]);
                adjacency[destination] = new IntNode(origin, adjacency[destination]);
            }
        }

        boolean[] visited = new boolean[n];
        String[][] components = new String[n][];
        int componentCount = 0;
        String[] buffer = new String[n];
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                int[] size = new int[1];
                visitWeakComponent(i, visited, adjacency, vertices, buffer, size);
                String[] component = new String[size[0]];
                System.arraycopy(buffer, 0, component, 0, size[0]);
                components[componentCount++] = component;
            }
        }
        String[][] effective = new String[componentCount][];
        System.arraycopy(components, 0, effective, 0, componentCount);
        return new WeakComponents(effective);
    }

    private void visitWeakComponent(int current, boolean[] visited, IntNode[] adjacency,
                                    Vertex[] vertices, String[] buffer, int[] size) {
        visited[current] = true;
        buffer[size[0]++] = vertices[current].getId();
        IntNode node = adjacency[current];
        while (node != null) {
            if (!visited[node.vertexIndex]) {
                visitWeakComponent(node.vertexIndex, visited, adjacency, vertices, buffer, size);
            }
            node = node.next;
        }
    }

    private static int indexOf(Vertex[] vertices, String id) {
        if (id == null) {
            return -1;
        }
        String normalized = id.trim();
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getId().equalsIgnoreCase(normalized)) {
                return i;
            }
        }
        return -1;
    }

    private static final class IntNode {
        private final int vertexIndex;
        private final IntNode next;

        private IntNode(int vertexIndex, IntNode next) {
            this.vertexIndex = vertexIndex;
            this.next = next;
        }
    }
}
