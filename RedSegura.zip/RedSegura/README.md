# RedSegura Sincelejo

Proyecto del **Parcial 2 de Estructura de Datos II** para modelar la movilidad de
una red de atención de emergencias mediante **árboles binarios de búsqueda, AVL,
grafos mixtos, BFS, DFS y Dijkstra**.

> Los tiempos son datos didácticos de simulación. No representan información
> oficial de tránsito ni tiempos reales de respuesta a emergencias.

- **Lenguaje:** Java 17
- **Construcción:** Maven
- **IDE objetivo:** Apache NetBeans
- **Pruebas:** JUnit 5
- **Aplicación:** consola interactiva `RedSeguraApplication`
- **Resultado de control:** ruta mínima `S02 -> S01 -> S07 -> S08` con **24 minutos**

---

## 1. Ejecución

Desde la carpeta raíz del proyecto:

```bash
mvn clean test
mvn package
java -jar target/redsegura-sincelejo-1.0.0.jar
```

Si no hay Maven instalado globalmente, el proyecto incluye Maven Wrapper:

```powershell
.\mvnw.cmd clean test
.\mvnw.cmd package
```

```bash
./mvnw clean test
./mvnw package
```

Demostración completa Q1..Q7 sin interacción:

```bash
java -jar target/redsegura-sincelejo-1.0.0.jar --demo
```

Medición breve reproducible de rendimiento:

```bash
java -jar target/redsegura-sincelejo-1.0.0.jar --benchmark
```

Ejecutar una consulta concreta, por ejemplo Q5:

```bash
java -jar target/redsegura-sincelejo-1.0.0.jar 5
```

En Apache NetBeans:

1. `File > Open Project`.
2. Seleccionar la carpeta `RedSegura` (contiene `pom.xml`).
3. Ejecutar el proyecto o la clase
   `co.edu.redsegura.app.RedSeguraApplication`.
4. Para `--demo`, configurar el argumento en las propiedades de ejecución.

La aplicación fuerza `System.out` y `System.err` a UTF-8 al iniciar, de modo que
las tildes, la eñe y los signos de apertura se ven bien directamente en
NetBeans, en PowerShell y en la consola de Windows, sin ejecutar `chcp` ni
agregar argumentos a la JVM. El proyecto fuente y Maven también están
configurados en UTF-8.

Si al ejecutar dentro de NetBeans todavía apareciera algún carácter extraño,
basta con hacer `Clean and Build` y volver a ejecutar para descartar clases
compiladas antes del ajuste. Como alternativa, en
`Properties > Run > VM Options` se pueden agregar:

```text
-Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8
```

---

## 2. Arquitectura

```mermaid
classDiagram
    RedSeguraApplication --> RedSeguraCore
    RedSeguraCore --> BinarySearchTree
    RedSeguraCore --> AvlTree
    RedSeguraCore --> MixedGraph
    RedSeguraCore --> GraphRepresentations
    RedSeguraCore --> BreadthFirstSearch
    RedSeguraCore --> DepthFirstSearch
    RedSeguraCore --> DijkstraSolver
    RedSeguraCore --> DataFactory

    MixedGraph *-- Vertex
    MixedGraph *-- Edge
    BinarySearchTree --> Vertex
    AvlTree --> Vertex
    GraphRepresentations --> MixedGraph
    BreadthFirstSearch --> MixedGraph
    DepthFirstSearch --> MixedGraph
    DijkstraSolver --> MixedGraph
    DataFactory ..> Vertex
    DataFactory ..> Edge
    DataFactory ..> MixedGraph
```

La aplicación solo conversa con `RedSeguraCore`. El núcleo usa los árboles y el
grafo mediante métodos públicos; no se leen campos privados de otro módulo.

### Paquetes

| Paquete | Responsabilidad |
|---|---|
| `co.edu.redsegura.model` | `Vertex`, `Edge`, encapsulamiento y validaciones |
| `co.edu.redsegura.trees` | ABB, AVL, resultados de búsqueda y rotaciones |
| `co.edu.redsegura.graph` | Grafo mixto, representaciones, BFS, DFS y Dijkstra |
| `co.edu.redsegura.core` | `DataFactory` y fachada `RedSeguraCore` |
| `co.edu.redsegura.app` | CLI, Q1..Q7 y medición de rendimiento |

---

## 3. Decisiones de diseño

1. **Sin colecciones para los algoritmos.** El código principal no usa
   `TreeSet`, `TreeMap`, `PriorityQueue`, `ArrayDeque`, `HashMap` ni ninguna
   estructura que resuelva los ejercicios. La cola BFS, el min-heap de Dijkstra,
   las listas de adyacencia, los arreglos dinámicos y los árboles son propios.
2. **Clave de los árboles.** La clave es la etiqueta del vértice. La comparación
   ignora mayúsculas/minúsculas y desempata con el orden natural.
3. **Alturas.** En la API pública, árbol vacío = `-1` y hoja = `0` (aristas).
   Internamente, el AVL almacena altura en nodos para balancear.
4. **Grafo mixto.** Una arista no dirigida genera dos arcos de recorrido con el
   mismo ID. Un arco dirigido genera un solo arco. Los algoritmos consumen los
   arcos salientes y, por tanto, respetan la orientación.
5. **Matriz de incidencia.** Arco dirigido: `+1` en origen y `-1` en destino.
   Arista no dirigida: `+1` en ambos extremos.
6. **Empates en Dijkstra.** Se actualiza solo con una distancia estrictamente
   menor. Esto conserva el primer predecesor y explica la ruta de control.
7. **Bloqueo Q6.** El bloqueo de `R16` se hace sobre una copia del grafo para que
   la demostración sea repetible y no altere las demás consultas. También existen
   `blockConnection` y `restoreConnection` para operar el grafo principal.
8. **Errores controlados.** IDs duplicados, pesos no positivos, extremos
   inexistentes y vértices ausentes lanzan excepciones con mensajes claros. La CLI
   las captura sin terminar el programa.

---

## 4. Conjunto de datos

### Vértices

| ID | Etiqueta | Tipo |
|---|---|---|
| S01 | UAJS Sede C | Universidad |
| S02 | UAJS Sede E | Universidad |
| S03 | Universidad de Sucre | Universidad |
| S04 | CECAR | Universidad |
| S05 | Hospital Universitario | Salud |
| S06 | Clínica Las Américas | Salud |
| S07 | Estación Central SETP | Transporte |
| S08 | Terminal de Transporte | Transporte |
| S09 | Parque Santander | Punto de encuentro |
| S10 | Mercado de Sincelejo | Comercio |
| S11 | PEP Argelia | Paradero |
| S12 | Glorieta Sincelejito | Movilidad |

### Conexiones

| ID | Origen | Destino | Tipo | Min |
|---|---|---|---|---|
| R01 | S01 | S07 | Dirigida | 4 |
| R02 | S07 | S01 | Dirigida | 6 |
| R03 | S01 | S09 | No dirigida | 5 |
| R04 | S02 | S01 | No dirigida | 8 |
| R05 | S02 | S06 | Dirigida | 10 |
| R06 | S06 | S05 | Dirigida | 4 |
| R07 | S05 | S09 | No dirigida | 6 |
| R08 | S09 | S10 | No dirigida | 3 |
| R09 | S10 | S08 | Dirigida | 8 |
| R10 | S08 | S10 | Dirigida | 9 |
| R11 | S03 | S12 | No dirigida | 4 |
| R12 | S12 | S09 | No dirigida | 7 |
| R13 | S04 | S11 | No dirigida | 6 |
| R14 | S11 | S07 | Dirigida | 8 |
| R15 | S07 | S09 | No dirigida | 3 |
| R16 | S07 | S08 | Dirigida | 12 |
| R17 | S09 | S03 | Dirigida | 7 |
| R18 | S12 | S04 | Dirigida | 9 |

---

## 5. Consultas obligatorias Q1..Q7

| Consulta | Implementación | Evidencia |
|---|---|---|
| Q1 | `RedSeguraCore.searchPlace` | Hospital Universitario: ABB en 3 comparaciones, AVL en 1 |
| Q2 | `AvlTree.RotationEvent` y `RedSeguraCore.avlRotationDemo` | LL, RR, LR y RL con estado antes/después |
| Q3 | `GraphRepresentations` | Lista, matriz ponderada y matriz de incidencia |
| Q4 | `BreadthFirstSearch`, `DepthFirstSearch` | Orden BFS/DFS, árbol BFS, ciclos y componentes débiles |
| Q5 | `DijkstraSolver` | `S02 -> S01 -> S07 -> S08`, 24 min |
| Q6 | `shortestPathAvoidingEdge(..., "R16")` | `S02 -> S01 -> S09 -> S10 -> S08`, 24 min |
| Q7 | `MixedGraph.getVertex("S99")` | `NoSuchElementException` controlada |

### Resultado Q1

Con los 12 vértices insertados en el orden S01..S12:

- ABB: altura 5, búsqueda del hospital en **3 comparaciones**.
- AVL: altura 3, búsqueda del hospital en **1 comparación** (la raíz quedó en el
  hospital tras el reequilibrio).

### Resultado Q5

Ruta de control:

```text
S02 (UAJS Sede E)
 -> S01 (UAJS Sede C)       R04, 8 min
 -> S07 (Estación Central SETP) R01, 4 min
 -> S08 (Terminal de Transporte) R16, 12 min
Total: 24 minutos
```

### Resultado Q6

Al bloquear `R16`, el costo total sigue siendo 24 minutos porque existe otra ruta
óptima:

```text
S02 -> S01 -> S09 -> S10 -> S08
R04 (8) + R03 (5) + R08 (3) + R09 (8) = 24 minutos
```

El cambio importante es la **secuencia de vértices y conexiones**, no el costo.
Esto demuestra que Dijkstra debe reconstruir el camino con predecesores y no solo
calcular la distancia.

---

## 6. Pruebas

Ejecución validada:

```text
Tests run: 9, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

Cobertura de `RedSeguraTest`:

1. Ruta mínima `S02 -> S08` igual a 24 minutos y camino exacto.
2. Bloqueo de `R16`, ruta alternativa y conservación del grafo original.
3. Rotaciones AVL LL, RR, LR y RL, balance y eliminación.
4. ABB: inserción, búsqueda con comparaciones, tres recorridos y eliminación de
   cero, uno y dos hijos.
5. Vértices inexistentes, IDs duplicados, pesos cero/negativos, bucles y
   etiquetas vacías.
6. Grafo desconectado: BFS/DFS parciales, dos componentes débiles y Dijkstra no
   alcanzable.
7. Coincidencia de lista/matrices, orientación y pesos.
8. BFS/DFS completos desde S02 y detección de ciclos.
9. Consulta controlada de `S99`.

Comando:

```bash
mvn test
```

---

## 7. Complejidad

`V` = vértices, `E` = conexiones, `n` = cantidad de nodos del árbol.

| Operación | Tiempo | Espacio | Observación |
|---|---|---|---|
| ABB inserción/búsqueda/eliminación | O(log n) promedio, O(n) peor | O(n) | Depende del orden de inserción |
| ABB recorridos y altura | O(n) | O(h) pila | `h` = altura |
| AVL inserción/búsqueda/eliminación | O(log n) | O(log n) pila, O(n) total | Rotaciones O(1) |
| AVL rotación LL/RR/LR/RL | O(1) | O(1) | Actualización de alturas |
| Agregar vértice | O(V) | O(V) | Validación lineal de ID |
| Agregar conexión | O(V + E) | O(E) | Validación de ID y extremos |
| Lista de adyacencia | O(V + E) | O(V + E) | Arcos salientes |
| Matriz de adyacencia | O(V²) | O(V²) | Consulta directa |
| Matriz de incidencia | O(V·E) | O(V·E) | Construcción de la matriz |
| BFS | O(V + E) | O(V) | Cola manual y visitados |
| DFS | O(V + E) | O(V) | Recursión y estados |
| Componentes débiles | O(V + E) | O(V + E) | Ignora orientación |
| Dijkstra con min-heap | O((V + E) log V) | O(V + E) | Relajación y predecesores |
| Reconstrucción de ruta | O(V) | O(V) | Desde destino a origen |

La medición `--benchmark` calienta la JVM y reporta ns/op y ms/op para búsqueda en
árboles, BFS, DFS y Dijkstra. Los valores dependen del hardware y son solo
indicativos; el análisis Big O es la referencia principal.

---

## 8. Estructura del repositorio

```text
RedSegura/
├── pom.xml
├── mvnw
├── mvnw.cmd
├── .mvn/wrapper/maven-wrapper.properties
├── README.md
├── src/
│   ├── main/java/co/edu/redsegura/
│   │   ├── model/
│   │   │   ├── Vertex.java
│   │   │   └── Edge.java
│   │   ├── trees/
│   │   │   ├── BinarySearchTree.java
│   │   │   ├── AvlTree.java
│   │   │   └── TreeSearchResult.java
│   │   ├── graph/
│   │   │   ├── MixedGraph.java
│   │   │   ├── GraphRepresentations.java
│   │   │   ├── BreadthFirstSearch.java
│   │   │   ├── BfsResult.java
│   │   │   ├── DepthFirstSearch.java
│   │   │   ├── DfsResult.java
│   │   │   ├── WeakComponents.java
│   │   │   ├── DijkstraSolver.java
│   │   │   └── ShortestPathResult.java
│   │   ├── core/
│   │   │   ├── DataFactory.java
│   │   │   └── RedSeguraCore.java
│   │   └── app/
│   │       ├── RedSeguraApplication.java
│   │       └── PerformanceProbe.java
│   └── test/java/co/edu/redsegura/RedSeguraTest.java
└── target/ (generado por Maven)
```

---

## 9. Checklist de entrega

- [x] Compila con Java 17 y Maven.
- [x] Incluye Maven Wrapper para ejecutar sin Maven global.
- [x] `mvn test` sin errores.
- [x] Ruta S02–S08 = 24 minutos.
- [x] Lista y matrices con el mismo orden S01..S12 / R01..R18.
- [x] README con ejecución, arquitectura y complejidad.
- [x] Sin dependencias algorítmicas externas.
- [x] CLI con Q1..Q7 y manejo de errores.
- [x] Pruebas de casos normales, inválidos, desconectados y bloqueo.
- [x] Diagrama de clases y decisiones de diseño.
